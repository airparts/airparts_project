@extends('master.back')

@section('content')

<div class="container-fluid">

   	<!-- Page Heading -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="d-sm-flex align-items-center justify-content-between">
                <h3 class=" mb-0 bc-title"> <b>{{ __('Announcement') }}</b> </h3>
                </div>
        </div>
    </div>

	<!-- Form -->
	<div class="row">

		<div class="col-xl-12 col-lg-12 col-md-12">

			<div class="card o-hidden border-0 shadow-lg">
				<div class="card-body ">
					<!-- Nested Row within Card Body -->
					<div class="row">
						<div class="col-lg-12">
							<div class="p-5">
								<div class="admin-form">

									@include('alerts.alerts')

                                    <div class="row justify-content-center">

                                        <div class="col-lg-8">

                                            <form action="{{ route('back.setting.update') }}" method="POST"
                                            enctype="multipart/form-data">

                                            @csrf


                                                <div class="form-group d-none">
                                                    <label for="announcement_type">{{ __('Select Type') }} *</label>
                                                    <select name="announcement_type" id="announcement_type" class="form-control" >
                                                        <option value="banner" {{$setting->announcement_type =='banner' ? 'selected' : ''}} >{{__('Announcement')}}</option>
                                                        <option value="newletter" {{$setting->announcement_type =='newletter' ? 'selected' : ''}}>{{__('Newsletter Popup')}}</option>
                                                    </select>
                                                </div>

                                                <div class="image-show">

                                                    <div class="form-group">
                                                        <label for="announcement_title">{{ __('Title') }} *</label>
                                                        <input type="text" name="announcement_title" class="form-control" id="announcement_title"
                                                            placeholder="{{ __('Popup Title') }}" value="{{ $setting->announcement_title }}" >
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="announcement_link">{{ __('Announcement Link') }} *</label>
                                                        <input type="text" name="announcement_link" class="form-control" id="announcement_link"
                                                            placeholder="{{ __('Link') }}" value="{{ $setting->announcement_link }}" >
                                                    </div>

                                                </div>



                                                <div>

                                                    <div class="form-group d-flex justify-content-center">
                                                        <button type="submit" class="btn btn-secondary ">{{ __('Submit') }}</button>
                                                    </div>

                                                </div>

                                            </form>

                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
