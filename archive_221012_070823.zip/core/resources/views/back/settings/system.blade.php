@extends('master.back')

@section('styles')
    <link rel="stylesheet" href="{{asset('assets/back/js/plugin/codemirror/codemirror.css')}}">
    <link rel="stylesheet" href="{{asset('assets/back/js/plugin/codemirror/monokai.css')}}">
@endsection


@section('content')

<div class="container-fluid">

	<!-- Page Heading -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="d-sm-flex align-items-center justify-content-between">
                <h3 class="mb-0 bc-title"><b>{{ __('Basic Information') }}</b></h3>

                </div>
        </div>
    </div>

    <div class="row">
        <div class="col-lg-12">
            @include('alerts.alerts')
        </div>
    </div>

	<div class="row">

		<div class="col-xl-12 col-lg-12 col-md-12">

			<div class="card o-hidden border-0 shadow-lg">
				<div class="card-body ">
					<!-- Nested Row within Card Body -->
                        <form class="admin-form" action="{{ route('back.setting.update') }}" method="POST"
									enctype="multipart/form-data">

                                    @csrf


					        <div class="row">
                                <div class="col-xl-3 col-lg-3">
                                    <div class="nav flex-column m-3 nav-pills nav-secondary" id="v-pills-tab" role="tablist" aria-orientation="vertical">
                                            <a class="nav-link active" data-toggle="pill" href="#basic">{{ __('Basic Information') }}</a>
                                            <a class="nav-link" data-toggle="pill" href="#media">{{ __('Media') }}</a>
                                            <a class="nav-link" data-toggle="pill" href="#seo">{{ __('Seo') }}</a>
                                            <a class="nav-link" data-toggle="pill" href="#footer">{{ __('Footer & Contact Page') }}</a>
                                    </div>
                                </div>
                                <div class="col-xl-9 col-lg-9">


                                        <input type="hidden" name="is_validate" value="1">

                                        <div class="">
                                            <div id="tabs">
                                            <!-- Tab panes -->
                                            <div class="tab-content">
                                            <div id="basic" class="tab-pane active"><br>
                                                <div class="row justify-content-center">
                                                    <div class="col-lg-8">
                                                        <div class="form-group">
                                                            <label for="title">{{ __('App Name') }} *</label>
                                                            <input type="text" name="title" class="form-control" id="title"
                                                                placeholder="{{ __('Enter Website Title') }}" value="{{ $setting->title }}" >
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-8">
                                                        <div class="form-group">
                                                            <label for="home_page_title">{{ __('Home Page Title') }} *</label>
                                                            <input type="text" name="home_page_title" class="form-control" id="home_page_title"
                                                                placeholder="{{ __('Enter Home Page Title') }}" value="{{ $setting->home_page_title }}" >
                                                        </div>
                                                    </div>

                                                    <div class="col-lg-8">
                                                        <div class="form-group">
                                                            <label for="primary_color">{{ __('Primary Colour Code') }} *</label>
                                                            <input type="text" data-jscolor="" name="primary_color" class="form-control" id="primary_color"
                                                                placeholder="{{ __('Enter Website Primary Colour Code') }}" value="{{ $setting->primary_color }}" >
                                                        </div>
                                                    </div>

                                                    <div class="col-lg-8">
                                                        <div class="form-group">
                                                            <label for="is_decimal">{{ __('Decimal Separator') }} *</label>
                                                            <select name="is_decimal" id="is_decimal" class="form-control">
                                                                <option value="1" {{$setting->is_decimal == 1 ? 'selected' : ''}}>On</option>
                                                                <option value="0" {{$setting->is_decimal == 0 ? 'selected' : ''}}>Off</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="col-lg-8">
                                                        <div class="form-group">
                                                            <label for="currency_direction">{{ __('Currency Direction') }} *</label>
                                                            <select name="currency_direction" id="currency_direction" class="form-control">
                                                                <option value="1" {{$setting->currency_direction == 1 ? 'selected' : ''}}>{{__('Left ($100.00)')}}</option>
                                                                <option value="0" {{$setting->currency_direction == 0 ? 'selected' : ''}}>{{__('Right (100.00$)')}}</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="col-lg-8">
                                                        <div class="form-group">
                                                            <label for="decimal_separator">{{ __('Decimal Separator') }} *</label>
                                                            <select name="decimal_separator" id="decimal_separator" class="form-control">
                                                                <option value="," {{$setting->decimal_separator == ',' ? 'selected' : ''}}>{{__('Comma (,)')}}</option>
                                                                <option value="." {{$setting->decimal_separator == '.' ? 'selected' : ''}}>{{__('Dot (.)')}}</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="col-lg-8">
                                                        <div class="form-group">
                                                            <label for="thousand_separator">{{ __('Thousand Separator') }} *</label>
                                                            <select name="thousand_separator" id="thousand_separator" class="form-control">
                                                                <option value="," {{$setting->thousand_separator == ',' ? 'selected' : ''}}>{{__('Comma (,)')}}</option>
                                                                <option value="." {{$setting->thousand_separator == '.' ? 'selected' : ''}}>{{__('Dot (.)')}}</option>
                                                            </select>
                                                        </div>
                                                    </div>

                                                </div>

                                            </div>

                                                
                                            <div id="media" class="tab-pane"><br>

                                                <div class="row justify-content-center">

                                                    <div class="col-lg-8">

                                                        <ul class="nav nav-pills nav-justified nav-secondary nav-pills-no-bd">
                                                            <li class="nav-item">
                                                                <a class="nav-link active" data-toggle="pill" href="#logo">{{ __('Logo') }}</a>
                                                            </li>
                                                            <li class="nav-item">
                                                                <a class="nav-link" data-toggle="pill" href="#favicon">{{ __('Favicon') }}</a>
                                                            </li>
                                                            <li class="nav-item">
                                                                <a class="nav-link" data-toggle="pill" href="#loader">{{ __('Loader') }}</a>
                                                            </li>
                                                        </ul>

                                                        <div class="tab-content">

                                                            <div id="logo" class="container tab-pane active"><br>
                                                            <div class="row justify-content-center">

                                                                <div class="col-lg-12 ">

                                                                    <div class="form-group">
                                                                        <label for="name">{{ __('White Logo') }}</label>
                                                                        <div class="col-lg-12 pb-1">
                                                                            <img class="admin-setting-img"
                                                                                src="{{ $setting->logo ? asset('assets/images/'.$setting->logo) : asset('assets/images/placeholder.png') }}"
                                                                                alt="No Image Found">
                                                                        </div>
                                                                        <span>{{ __('Image Size Should Be 140 x 40.') }}</span>
                                                                    </div>

                                                                    <div class="form-group position-relative ">
                                                                        <label class="file">
                                                                            <input type="file"  accept="image/*"  class="upload-photo" name="logo" id="file" aria-label="File browser example">
                                                                            <span class="file-custom text-left">{{ __('Upload Image...') }}</span>
                                                                        </label>
                                                                    </div>

                                                                </div>
                                                                <div class="col-lg-12">
                                                                    <div class="form-group">
                                                                        <label for="name">{{ __('Footer Logo') }}</label>
                                                                        <div class="col-lg-12 pb-1">
                                                                            <img class="admin-setting-img"
                                                                                src="{{ $setting->footer_logo ? asset('assets/images/'.$setting->footer_logo) : asset('assets/images/placeholder.png') }}"
                                                                                alt="No Image Found">
                                                                        </div>
                                                                        <span>{{ __('Image Size Should Be 140 x 40.') }}</span>
                                                                    </div>

                                                                    <div class="form-group position-relative ">
                                                                        <label class="file">
                                                                            <input type="file"  accept="image/*"  class="upload-photo" name="footer_logo" id="file" aria-label="File browser example">
                                                                            <span class="file-custom text-left">{{ __('Upload Image...') }}</span>
                                                                        </label>
                                                                    </div>
                                                                </div>

                                                            </div>
                                                            </div>

                                                            <div id="favicon" class="container tab-pane"><br>
                                                                <div class="row justify-content-center">

                                                                    <div class="col-lg-12">

                                                                        <div class="form-group">
                                                                            <label for="name">{{ __('Current Image') }}</label>
                                                                            <div class="col-lg-12 pb-1">
                                                                                <img class="admin-setting-img my-mw-100"
                                                                                    src="{{ $setting->favicon ? asset('assets/images/'.$setting->favicon) : asset('assets/images/placeholder.png') }}"
                                                                                    alt="No Image Found">
                                                                            </div>
                                                                            <span>{{ __('Image Size Should Be 16 x 16.') }}</span>
                                                                        </div>

                                                                        <div class="form-group position-relative ">
                                                                            <label class="file">
                                                                                <input type="file"  accept="image/*"  class="upload-photo" name="favicon" id="file" aria-label="File browser example">
                                                                                <span class="file-custom text-left">{{ __('Upload Image...') }}</span>
                                                                            </label>
                                                                        </div>

                                                                    </div>

                                                                </div>
                                                            </div>

                                                            <div id="loader" class="container tab-pane"><br>
                                                                <div class="row justify-content-center">

                                                                    <div class="col-lg-12">
                                                                        <div class="form-group">
                                                                            <label class="switch-primary">
                                                                            <input type="checkbox" class="switch switch-bootstrap " name="is_loader" value="1" {{ $setting->is_loader == 1 ? 'checked' : '' }}>
                                                                            <span class="switch-body"></span>
                                                                            <span class="switch-text">{{ __('Display Loader') }}</span>
                                                                            </label>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <label for="name">{{ __('Current Image') }}</label>
                                                                            <div class="col-lg-12 pb-1">
                                                                                <img class="admin-setting-img my-mw-100"
                                                                                    src="{{ $setting->loader ? asset('assets/images/'.$setting->loader) : asset('assets/images/placeholder.png') }}"
                                                                                    alt="No Image Found">
                                                                            </div>
                                                                        </div>
                                                                        <div class="form-group position-relative ">
                                                                            <label class="file">
                                                                                <input type="file"  accept="image/*"  class="upload-photo" name="loader" id="file" aria-label="File browser example">
                                                                                <span class="file-custom text-left">{{ __('Upload Image...') }}</span>
                                                                            </label>
                                                                        </div>



                                                                    </div>
                                                                </div>

                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                            <div id="seo" class="tab-pane"><br>

                                                    <div class="row justify-content-center">

                                                        <div class="col-lg-8">



                                                            <div class="form-group">
                                                                <label for="meta_keywords">{{ __('Site Meta Keywords') }} *</label>
                                                                <input type="text" name="meta_keywords" class="tags" id="meta_keywords"
                                                                    placeholder="{{ __('Site Meta Keywords') }}" value="{{ $setting->meta_keywords }}" >
                                                            </div>

                                                            <div class="form-group">
                                                                <label for="meta_description">{{ __('Site Meta Description') }} *</label>
                                                                <textarea name="meta_description" id="meta_description" class="form-control" rows="5"
                                                                    placeholder="{{ __('Enter Site Meta Description') }}"
                                                                    >{{ $setting->meta_description }}</textarea>
                                                            </div>

                                                        </div>

                                                    </div>

                                            </div>

            
                                            <div id="footer" class="tab-pane"><br>

                                                <div class="row justify-content-center">

                                                    <div class="col-lg-8">

                                                        <ul class="nav nav-pills nav-justified nav-secondary nav-pills-no-bd">
                                                            <li class="nav-item">
                                                                <a class="nav-link active" data-toggle="pill" href="#footer_basic">{{ __('Basic') }}</a>
                                                            </li>
                                                            <li class="nav-item">
                                                                <a class="nav-link" data-toggle="pill" href="#footer_link">{{ __('Social Link') }}</a>
                                                            </li>
                                                        </ul>

                                                        <div class="tab-content">

                                                            <div id="footer_basic" class="container tab-pane active"><br>
                                                            <div class="row justify-content-center">

                                                                <div class="col-lg-12">

                                                                        <div class="form-group">
                                                                            <label for="footer_address">{{ __('Store Address') }} *</label>
                                                                            <input type="text" name="footer_address" class="form-control" id="footer_address"
                                                                                placeholder="{{ __('Store Address') }}" value="{{ $setting->footer_address }}" >
                                                                        </div>

                                                                        <div class="form-group">
                                                                            <label for="footer_phone">{{ __('Store Phone Number') }} *</label>
                                                                            <input type="text" name="footer_phone" class="form-control" id="footer_phone"
                                                                                placeholder="{{ __('Store Phone Number') }}" value="{{ $setting->footer_phone }}" >
                                                                        </div>


                                                                        <div class="form-group">
                                                                            <label for="footer_email">{{ __('Store Email') }} *</label>
                                                                            <input type="email" name="footer_email" class="form-control" id="footer_email"
                                                                                placeholder="{{ __('Store Email') }}" value="{{ $setting->footer_email }}" >
                                                                        </div>

                                                                    <div class="form-group">
                                                                        <label for="footer_gateway_img">{{ __('Current Gateway Image') }}</label>
                                                                        <div class="col-lg-12 pb-1">
                                                                            <img class="admin-setting-img"
                                                                                src="{{ $setting->footer_gateway_img ? asset('assets/images/'.$setting->footer_gateway_img) : asset('assets/images/placeholder.png') }}"
                                                                                alt="No Image Found">
                                                                        </div>
                                                                        <span>{{ __('Image Size Should Be 324 x 31.') }}</span>
                                                                    </div>

                                                                    <div class="form-group position-relative ">
                                                                        <label class="file">
                                                                            <input type="file"  accept="image/*"  class="upload-photo" name="footer_gateway_img" id="footer_gateway_img" aria-label="File browser example">
                                                                            <span class="file-custom text-left">{{ __('Upload Image...') }}</span>
                                                                        </label>
                                                                    </div>

                                                                        <div class="form-group">
                                                                            <label for="copy_right">{{ __('Copyright') }} *</label>
                                                                            <textarea name="copy_right" id="copy_right" class="form-control" rows="3"
                                                                            placeholder="{{ __('Copyright') }}"
                                                                            >{{ $setting->copy_right }}</textarea>
                                                                        </div>


                                                                </div>

                                                            </div>
                                                            </div>

                                                            <div id="footer_link" class="container tab-pane"><br>
                                                                <div class="row justify-content-center">

                                                                    <div class="col-lg-12">
                                                                        <div id="social-section">
                                                                            @php
                                                                            $links = json_decode($setting->social_link,true)['links'];
                                                                            $icons = json_decode($setting->social_link,true)['icons'];
                                                                            @endphp
                                                                            @foreach ($links as $link_key => $link)
                                                                            <div class="d-flex">
                                                                                <div>
                                                                                    <div class="form-group">
                                                                                        <button
                                                                                            class="btn btn-secondary social-picker"
                                                                                            name="social_icons[]"
                                                                                            data-icon="{{$icons[$link_key]}}">
                                                                                        </button>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="flex-grow-1">
                                                                                    <div class="form-group">
                                                                                        <input type="text" class="form-control"
                                                                                            name="social_links[]"
                                                                                            placeholder="{{ __('Social Link') }}" value="{{$link}}">
                                                                                        </div>
                                                                                </div>
                                                                                <div class="flex-btn">
                                                                                    <button type="button" class="btn btn-success add-social" data-text="{{ __('Social Link') }}"> <i class="fa fa-plus"></i> </button>
                                                                                </div>
                                                                            </div>
                                                                            @endforeach



                                                                        </div>

                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>

                                                    </div>

                                                </div>

                                            </div>



                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group d-flex justify-content-center">
                                        <button type="submit" class="btn btn-secondary ">{{ __('Submit') }}</button>
                                    </div>


                                </div>
						    </div>
                        </form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

@endsection


@section('scripts')
    <script src="{{asset('assets/back/js/plugin/codemirror/codemirror.js')}}"></script>
    <script src="{{asset('assets/back/js/plugin/codemirror/css.js')}}"></script>
    <script>

        $(document).ready(function () {
            var editor = CodeMirror.fromTextArea(document.getElementById("custom_css_area"), {
                mode: "text/css",
                matchBrackets: true,
                theme: "monokai"
            });
        });
    </script>
@endsection

