@extends('master.front')

@section('title')
 { $setting->home_page_title }} - Post Ad
@endsection
@section('styleplugins')
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.4.0/min/dropzone.min.css">
@endsection

@section('content')
<div class="about-us-bottom-area section-top-gap-100">
  <div class="section-content-gap">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <h3 class="section-title">
                  <span class="red-line"></span> Post Ad <span class="red-circle"></span>
                </h3>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
    <form action="{{ url('post_ad') }}" method="post" role="form">
        @csrf
      <div class="container">
          <div class="row m-0">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
              <div class="form-group">
                <h6 class="control-label">Title of the Product</h6>
                <input type="text" name="title" class="form-control" value="" placeholder="Title">
              </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                <div class="form-group">
                    <h6 class="control-label">Condition</h6>
                    <select class="form-control" name="condition">
                        <option value="">Brand New</option>
                        <option value="">Used</option>
                        <option value="">Normal</option>
                        <option value="">Damaged</option>
                        <option value="">Genuine</option>
                    </select>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                <div class="form-group">
                    <h6 class="control-label">Category</h6>
                    <select class="form-control" name="category">
                        @foreach($categories as $category)
                        <option value="{{ $category->id }}">{{ $category->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                <div class="form-group">
                    <h6 class="control-label">Price</h6>
                    <div class="input-group">
                      <div class="input-group-prepend">
                        <span class="input-group-text" id="basic-addon1">$</span>
                      </div>
                      <input type="text" class="form-control" placeholder="200.51" aria-describedby="basic-addon1" name="price">
                    </div>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                <div class="form-group">
                    <h6 class="control-label">Car Makes</h6>
                    <select class="form-control" name="brand">
                        @foreach($brands as $brand)
                        <option value="{{ $brand->id }}">{{ $brand->name }}</option>
                        @endforeach
                    </select>
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                <div class="form-group">
                    <h6 class="control-label">Car Model</h6>
                    <input type="text" class="form-control" name="model" placeholder="Car Model">
                </div>
            </div>
            <div class="col-lg-2 col-md-4 col-sm-6 col-12">
                <div class="form-group">
                    <h6 class="control-label">Car Year</h6>
                    <select class="form-control" name="year">
                        @for($i=2000; $i<=date('Y'); $i++)
                        <option value="{{ $i }}">{{ $i }}</option>
                        @endfor
                    </select>
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
              <div class="form-group">
                <h6 class="control-label">Item Description</h6>
                <textarea class="form-control" name="description" rows="3" placeholder="Enter description here..."></textarea>
              </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="form-group">
                    <h6 class="control-label">Contact Name</h6>
                    <input type="text"  class="form-control" value="" placeholder="Michel B. Jordan" name="contact_name">
                </div>
            </div>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="form-group">
                    <h6 class="control-label">Contact Number</h6>
                    <input type="text" class="form-control" value="" placeholder="+27 123 456 7890" name="contact_number">
                </div>
            </div>
            <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                <div class="form-group">
                    <h6 class="control-label">Location</h6>
                    <input type="text" name="location" class="form-control" value="" placeholder="Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor" name="">
                </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
              <div class="form-group">
                <h6 class="control-label">Images</h6>
                <div class="row">
                  <div class="dropzone" id="dropzone">
                      <div class="dz-default dz-message">Drop images here or click to upload</div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-12 mt-3 pl-0">
              <button type="submit" class="btn btn-danger mr-2">Post Ad</button>
              <button type="button" class="btn btn-dark">Preview Ad</button>
            </div>
          </div>
      </div>
    </form>
  </div>
    
</div>
@endsection
@section('script')
<script src="https://cdnjs.cloudflare.com/ajax/libs/dropzone/5.4.0/dropzone.js"></script>
<script type="text/javascript">
        Dropzone.options.dropzone =
         {
            url: '{{ url("post_ad") }}',
            autoProcessQueue: false,
            autoDiscover:false,
            maxFilesize: 12,
            renameFile: function(file) {
                var dt = new Date();
                var time = dt.getTime();
               return time+file.name;
            },
            acceptedFiles: ".jpeg,.jpg,.png,.gif",
            addRemoveLinks: true,
            timeout: 5000,
            success: function(file, response) 
            {
                console.log(response);
            },
            error: function(file, response)
            {
               return false;
            }
};
</script>
@endsection