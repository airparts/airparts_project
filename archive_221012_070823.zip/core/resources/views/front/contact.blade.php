@extends('master.front')
@section('meta')
<meta name="keywords" content="{{$setting->meta_keywords}}">
<meta name="description" content="{{$setting->meta_description}}">
@endsection
@section('title')
    {{__('Contact')}}
@endsection

@section('content')
<div class="about-us-bottom-area section-top-gap-100">
  <div class="section-content-gap">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> Contact Us <span class="red-circle"></span>
                        </h3>  
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
      <div class="container">
          <div class="row m-0">
            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
              <h4 class="font-weight-bold">Get In Touch</h4>
              <p>
                <ul class="list-unstyled text-sm">
                  <li><span class="text-muted">{{__('Monday-Friday')}}:</span>{{$setting->friday_start}} - {{$setting->friday_end}}</li>
                  <li><span class="text-muted">{{__('Saturday')}}:</span>{{$setting->satureday_start}} - {{$setting->satureday_end}}</li>
                </ul>
              </p>
              <p>
                <ul class="list-icon margin-bottom-1x">
                  <li><strong><i class="fa fa-map-marker text-red mr-2 font18"></i></strong>{{$setting->footer_address}}</li>
                  <li><strong><i class="fa fa-phone text-red mr-2 font18"></i></strong>{{$setting->footer_phone}}</li>
                  <li>
                    <strong><i class="fa fa-clock-o text-red mr-2 font18"></i></strong> open 24/7
                  </li>
                </ul>
              </p>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
              <form class="row mt-2" method="Post" action="{{route('front.contact.submit')}}">
                @csrf
                <div class="form-group">
                  <h4 class="font-weight-bold">Leaver a Reply</h4>
                  <p>Tell Us Your Message , We will review your request.</p>
                </div>
                <div class="form-group mb-2">
                  <textarea class="form-control" name="message" rows="4" placeholder="Your comment"></textarea>
                  @error('message')
                    <p class="text-danger">{{$message}}</p>
                    @enderror
                </div>
                <div class="form-group mb-2">
                  <input type="text" name="first_name" placeholder="First Name*" class="form-control">
                  @error('first_name')
                    <p class="text-danger">{{$message}}</p>
                    @enderror
                </div>
                <div class="form-group mb-2">
                  <input type="text" name="last_name" placeholder="Name*" class="form-control">
                  @error('last_name')
                    <p class="text-danger">{{$message}}</p>
                    @enderror
                </div>
                <div class="form-group mb-2">
                  <input type="email" name="email" placeholder="Email*" class="form-control">
                  @error('email')
                    <p class="text-danger">{{$message}}</p>
                    @enderror
                </div>
                <div class="form-group mb-2">
                  <input type="text" name="phone" placeholder="Email*" class="form-control">
                  @error('phone')
                    <p class="text-danger">{{$message}}</p>
                    @enderror
                </div>
                <div class="form-group">
                  <button type="submit" class="btn btn-danger-o">Submit Comment</button>
                </div>
              </form>
            </div>
          </div>
      </div>
  </div>
    
</div>

<div class="section-content-gap section-top-gap-100">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> About Us <span class="red-circle"></span>
                        </h3>  
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
      <div class="container">
        <div class="row m-0">
          <div class="col-12">
            <p>
              Same as you, we are car enthusiasts who love to modify our cars.<br /><br />To save cost, a lot of buyers,
              including us prefer to shop in used car parts market first before consider buying brand new; however,
              availability is limited by geographic location.<br /><br />When looking internationally, overseas websites are
              usually written in foreign languages, specific car make, model and parts’ terminology could be difficult to
              translate from local slangs. <br /><br />To make the parts hunting process worse, used car parts hosting
              websites are fragmented and often do not have no specific model fitment guidance. Buyers could spend hours
              scrolling through hundreds of pages across different websites looking for specific car parts without
              success.<br /><br />Even when successfully identify a specific car part overseas, buyers might get put off due
              to complicated and lengthy importing process where shipping cost, import duties, relevant country specific
              taxes and estimated time of arrival (ETA) are difficult to be estimated, local domestic pickup and
              internationally shipping are also not easy to be organised.<br /><br />In August 2021, AirParts was born.<br /><br />Our
              goal is to build a customer-to-customer (C2C) centric global car parts trading platform to:<br /><br />1.
              Eliminate local availability limitation by allowing willing sellers and buyers in different geographic
              locations to trade anywhere in the world.<br />2. Eliminate the language barrier by utilising Natural Language
              Processing (NLP) neural machine translator to translate international car parts ads that are written in
              foreign languages slangs to proper English.<br />3. Reduce significant browsing time for end-users where the
              platform will act as a purpose-built search engine to locate all car parts hosted from websites anywhere in
              the world.<br />4. Reclassify all used car parts ads located down to specific car make, model and year by
              using supervised Machine Learning (ML) classification techniques.<br />5. Provide automatic parts fitment
              matching functionality by pairing reclassified car parts ads with registration number plate recognition
              technology via NEVDIS (National Exchange of Vehicle and Driver Information
              System) database.<br />6. Eliminate ambiguity for importing by implementing accurate shipping calculator that
              outlines shipping cost, import duties, relevant country specific taxes and estimated time of arrival (ETA)
              based on product and buyer’s location.<br />7.
              Provide a one-stop-shop experience from domestic pickup, internationally shipping to installation arrangement
              via the affiliated local mechanic workshop.<br /><br />We hope you enjoy your experience with us.<br /><br />Eddie
              Lee<br /><br />Founder &amp; Director of AirParts
            </p>
          </div>
        </div>
      </div>
  </div>

  <div class="section-content-gap section-top-gap-100">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> FAQ <span class="red-circle"></span>
                        </h3>  
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
      <div class="container">
        <div class="row m-0">
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 mt-5">
              <div class="panel-group" id="accordion1" role="tablist" aria-multiselectable="true">
                  <div class="panel panel-default faq">
                      <div class="panel-heading1" role="tab" id="headingTwo">
                          <h6 class="font-weight-bold panel-title"> 
                            <a data-toggle="collapse" data-parent="#accordion1" href="#collapse1" aria-expanded="true" aria-controls="collapse1">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy?</a>
                          </h6>
                      </div>
                      <div id="collapse1" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingTwo">
                          <div class="panel-body mt-5">
                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 mt-5">
              <div class="panel-group" id="accordion2" role="tablist" aria-multiselectable="true">
                  <div class="panel panel-default faq">
                      <div class="panel-heading1" role="tab" id="heading2">
                          <h6 class="font-weight-bold panel-title"> 
                            <a data-toggle="collapse" data-parent="#accordion2" href="#collapse2" aria-expanded="true" aria-controls="collapse2">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy?</a>
                          </h6>
                      </div>
                      <div id="collapse2" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading2">
                          <div class="panel-body mt-5">
                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 mt-5">
              <div class="panel-group" id="accordion3" role="tablist" aria-multiselectable="true">
                  <div class="panel panel-default faq">
                      <div class="panel-heading1" role="tab" id="heading3">
                          <h6 class="font-weight-bold panel-title"> 
                            <a data-toggle="collapse" data-parent="#accordion3" href="#collapse3" aria-expanded="true" aria-controls="collapse3">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy?</a>
                          </h6>
                      </div>
                      <div id="collapse3" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading3">
                          <div class="panel-body mt-5">
                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 mt-5">
              <div class="panel-group" id="accordion4" role="tablist" aria-multiselectable="true">
                  <div class="panel panel-default faq">
                      <div class="panel-heading1" role="tab" id="heading4">
                          <h6 class="font-weight-bold panel-title"> 
                            <a data-toggle="collapse" data-parent="#accordion4" href="#collapse4" aria-expanded="true" aria-controls="collapse4">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy?</a>
                          </h6>
                      </div>
                      <div id="collapse4" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading4">
                          <div class="panel-body mt-5">
                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 mt-5">
              <div class="panel-group" id="accordion5" role="tablist" aria-multiselectable="true">
                  <div class="panel panel-default faq">
                      <div class="panel-heading1" role="tab" id="heading5">
                          <h6 class="font-weight-bold panel-title"> 
                            <a data-toggle="collapse" data-parent="#accordion5" href="#collapse5" aria-expanded="true" aria-controls="collapse5">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy?</a>
                          </h6>
                      </div>
                      <div id="collapse5" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading5">
                          <div class="panel-body mt-5">
                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 mt-5">
              <div class="panel-group" id="accordion6" role="tablist" aria-multiselectable="true">
                  <div class="panel panel-default faq">
                      <div class="panel-heading1" role="tab" id="heading6">
                          <h6 class="font-weight-bold panel-title"> 
                            <a data-toggle="collapse" data-parent="#accordion6" href="#collapse6" aria-expanded="true" aria-controls="collapse6">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy?</a>
                          </h6>
                      </div>
                      <div id="collapse6" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading6">
                          <div class="panel-body mt-5">
                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 mt-5">
              <div class="panel-group" id="accordion7" role="tablist" aria-multiselectable="true">
                  <div class="panel panel-default faq">
                      <div class="panel-heading1" role="tab" id="heading7">
                          <h6 class="font-weight-bold panel-title"> 
                            <a data-toggle="collapse" data-parent="#accordion7" href="#collapse7" aria-expanded="true" aria-controls="collapse7">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy?</a>
                          </h6>
                      </div>
                      <div id="collapse7" class="panel-collapse collapse in show" role="tabpanel" aria-labelledby="heading7">
                          <div class="panel-body mt-5">
                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 mt-5">
              <div class="panel-group" id="accordion8" role="tablist" aria-multiselectable="true">
                  <div class="panel panel-default faq">
                      <div class="panel-heading1" role="tab" id="heading8">
                          <h6 class="font-weight-bold panel-title"> 
                            <a data-toggle="collapse" data-parent="#accordion8" href="#collapse8" aria-expanded="true" aria-controls="collapse8">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy?</a>
                          </h6>
                      </div>
                      <div id="collapse8" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading8">
                          <div class="panel-body mt-5">
                            <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet.</p>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
        </div>
      </div>
  </div>

  <div class="section-content-gap section-top-gap-100">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> Invest on Us <span class="red-circle"></span>
                        </h3>  
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
      <div class="container">
        <div class="row m-0">
          <div class="col-lg-12 col-md-12 col-sm-12 col-12">
              <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-3 col-12 mb-1">
                  <img src="{{ asset('assets/img/mask-group-10@1x.png') }}" width="100%" height="auto" />
                </div>
                <div class="col-lg-9 col-md-9 col-sm-9 col-12">
                  <h6 class="font-weight-bold">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor</h6>
                  <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>
                  <button class="btn btn-danger-o">Know More</button>
                </div>
              </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-12 mt-3">
              <div class="banner-single zIndex1">
                <a  class="banner-img-link">
                    <img class="banner-img banner-img-big" src="{{ asset('assets/img/mask-group-11@1x.png') }}" alt="">
                </a>
                <div class="banner-content">
                    <h3 class="section-title text-white mt-5 pt-5"><span class="white-line"></span> Become a Workshop Partner <span class="white-circle"></span> </h3>
                    <div class="banner-content-wrapper mt-5">
                        <div class="container">
                          <div class="row pl-5 ml-5">
                              <div class="col-lg-10 col-md-10 col-sm-12 col-12">
                                  <p class="text-white"><strong>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</strong></p>
                              </div>
                              <div class="col-lg-2 col-md-2 col-sm-12 col-12">
                                  <button class="btn btn-danger">Know More</button>
                              </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <div class="col-12 mt-15 mb-10">
              <div class="row">
                <div class="col-lg-5 col-md-5 col-sm-12 col-12 mb-1">
                  <img src="{{ asset('assets/img/mask-group-12@1x.png') }}" width="100%" height="auto" />
                </div>
                <div class="col-lg-7 col-md-7 col-sm-12 col-12">
                  <h3 class="font-weight-bold">Become a Shipping Partner</h3>
                  <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>
                  <div class="form-group">
                    <h6>Enter your Email</h6>
                    <input type="email" name="" class="form-control" placeholder="Email*">
                  </div>
                  <button class="btn btn-danger-o mt-3">Get Started</button>
                </div>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-12 mb-2">
                  <h3 class="font-weight-bold">Terms & Conditions</h3>
                  <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>
                  <button class="btn btn-danger-o">Read More</button>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                  <h3 class="font-weight-bold">Privacy Statement</h3>
                  <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>
                  <button class="btn btn-danger-o">Read More</button>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-12 mt-10">
              <div class="row">
                <div class="col-lg-5 col-md-5 col-sm-12 col-12 mb-1">
                  <img src="{{ asset('assets/img/mask-group-13@1x.png') }}" width="100%" height="auto" />
                </div>
                <div class="col-lg-7 col-md-7 col-sm-12 col-12">
                  <div class="form-group mb-3">
                    <h6 class="font-weight-bold mt-0">Order ID</h6>
                    <input type="text" name="" class="form-control" placeholder="Enter order id">
                  </div>
                  <div class="form-group mb-3">
                    <h6 class="font-weight-bold">Description</h6>
                    <textarea class="form-control" rows="4" placeholder="Describe the Problem in Details"></textarea>
                  </div>
                  <button class="btn btn-danger-o">Submit</button>
                </div>
              </div>
            </div>
        </div>
      </div>
  </div>
@endsection
