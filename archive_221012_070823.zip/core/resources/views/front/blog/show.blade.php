@extends('master.front')
@section('title')
    {{__('Blog Details')}}
@endsection

@section('content')
<div class="about-us-bottom-area section-top-gap-100">
  <div class="section-content-gap">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span>Blog Details <span class="red-circle"></span>
                        </h3>  
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-12 pl-5">
                      <form action="{{route('front.blog')}}" method="get">
                      <div class="form-group d-flex float-right">
                        <div class="form-group w200x mr-3">
                          <select class="form-control" name="type">
                              <option value="">All Posts</option>
                              <option value="">Recent Posts</option>
                              <option value="">Mostly Viewed</option>
                          </select>
                        </div>
                        <div class="input-group mb-3 w200x">
                          <span class="input-group-text" style="background: none;" id="basic-addon1"><i class="fa fa-search"></i></span>
                          <input type="text" name="search" class="form-control" placeholder="Search Blog" aria-label="Search" aria-describedby="basic-addon1" style="border-left: 0;height: 42px;">
                        </div>
                      </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
      <div class="container">
          <div class="row m-0">
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
              @if(isset(json_decode($post->photo, true)[array_key_first(json_decode($post->photo, true))]))
                <img src="{{ asset('assets/images/' . json_decode($post->photo, true)[array_key_first(json_decode($post->photo, true))]) }}" alt="" class="blog-feed-img">
                @else
                <img src="https://via.placeholder.com/600" alt="" class="blog-feed-img">
                @endif
              <h4 class="font-weight-bold mt-3 mb-3"><a href="{{route('front.blog.details',$post->slug)}}">{{ $post->title }}</a></h4>
              <p>{!! $post->details !!}</p>
              <span class="text-secondary"><i class="fa fa-calendar"></i> {{ date('F d, Y',strtotime($post->created_at)) }}</span>
            </div>
          </div>
          <div class="row m-0">
            <div class="d-flex flex-wrap justify-content-between align-items-center pt-3 pb-4">

                    @if ($post->tags)
                    <div class="pb-2">
                        {{ __('Tags :') }}
                        @foreach (explode(',',$post->tags) as $tag)
                        @if($loop->last)
                        <a class="text-sm text-muted navi-link" href="{{route('front.blog').'?tag='.$tag}}">{{$tag}}</a>
                        @else
                        <a class="text-sm text-muted navi-link" href="{{route('front.blog').'?tag='.$tag}}">{{$tag}}</a>,
                        @endif
                        @endforeach
                    </div>
                    @endif
                    <div class="d-flex align-items-center">
                        <span class="text-muted mr-1">{{__('Share')}}: </span>
                        <div class="d-flex a2a_kit">
                          <a class=" a2a_button_facebook" >
                              <i class="text-red fab fa-facebook mr-3 font18"></i>
                          </a>
                          <a class="a2a_button_twitter" >
                              <i class="text-red fab fa-twitter mr-3 font18"></i>
                          </a>
                          <a class="   a2a_button_pinterest">
                              <i class="text-red fab fa-instagram font18"></i>
                          </a>
                        </div>
                        <script async src="https://static.addtoany.com/menu/page.js"></script>
                    </div>
                </div>

            @if ($setting->is_disqus == 1)

                <div class="card mb-30">
                    <div class="card-body">
                      {!!$setting->disqus!!}
                    </div>
                </div>
            @endif
          </div>
      </div>
  </div>
    
</div>

@endsection
