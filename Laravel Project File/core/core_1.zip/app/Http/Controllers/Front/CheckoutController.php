<?php

namespace App\Http\Controllers\Front;

use App\{
    Models\Order,
    Models\TrackOrder,
    Models\PromoCode,
    Helpers\EmailHelper,
    Models\Notification,
    Models\PaymentSetting,
    Traits\StripeCheckout,
    Traits\MollieCheckout,
    Traits\PaypalCheckout,
    Traits\PaystackCheckout,
    Http\Controllers\Controller,
    Http\Requests\PaymentRequest,
    Traits\CashOnDeliveryCheckout,
    Traits\BankCheckout,
};
use App\Helpers\PriceHelper;
use App\Helpers\SmsHelper;
use App\Models\Currency;
use App\Models\Item;
use App\Models\Setting;
use App\Models\ShippingService;
use App\Models\State;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Session;
use Mollie\Laravel\Facades\Mollie;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Config;

class CheckoutController extends Controller
{

    use StripeCheckout {
        StripeCheckout::__construct as private __stripeConstruct;
    }
    use PaypalCheckout {
        PaypalCheckout::__construct as private __paypalConstruct;
    }
    use MollieCheckout {
        MollieCheckout::__construct as private __MollieConstruct;
    }

    use BankCheckout;
    use PaystackCheckout;
    use CashOnDeliveryCheckout;

    public function __construct()
    {
        $setting = Setting::first();
        if($setting->is_guest_checkout != 1){
            $this->middleware('auth');
        }
        $this->middleware('localize');
        $this->__stripeConstruct();
        $this->__paypalConstruct();
    }

	public function ship_address()
	{
        
        if (!Session::has('cart')) {
            return redirect(route('front.cart'));
        }
        $data['user'] = Auth::user() ? Auth::user() : null;
        $cart = Session::get('cart');
        $total_tax = 0;
        $cart_total = 0;
        $total = 0;
        
        foreach($cart as $key => $item){
            $total += ($item['main_price'] + $item['attribute_price']) * $item['qty'];
            $cart_total = $total;
            $item = Item::findOrFail($key);
            if($item->tax){
                $total_tax += $item::taxCalculate($item);
            }
        }

        
        $shipping = [];
        if(ShippingService::whereStatus(1)->whereId(1)->whereIsCondition(1)->exists()){
            $shipping = ShippingService::whereStatus(1)->whereId(1)->whereIsCondition(1)->first();
            if($cart_total >= $shipping->minimum_price){
                $shipping = $shipping;
            }else{
                $shipping = [];
            }
        }

        if(!$shipping){
            $shipping = ShippingService::whereStatus(1)->where('id','!=',1)->first();
        }
        $discount = [];
        if(Session::has('coupon')){
            $discount = Session::get('coupon');
        }

        if (!PriceHelper::Digital()){
            $shipping = null;
        }

        $grand_total = ($cart_total + ($shipping?$shipping->price:0)) + $total_tax;
        $grand_total = $grand_total - ($discount ? $discount['discount'] : 0);
        $state_tax = Auth::check() && Auth::user()->state_id ? Auth::user()->state->price : 0;
        $total_amount = $grand_total + $state_tax;

        $data['cart'] = $cart;
        $data['cart_total'] = $cart_total;
        $data['grand_total'] = $total_amount;
        $data['discount'] = $discount;
        $data['shipping'] = $shipping;
        $data['tax'] = $total_tax;
        $data['payments'] = PaymentSetting::whereStatus(1)->get();
        return view('front.checkout.billing',$data);

    }



    public function billingStore(Request $request)
    {

        if($request->same_ship_address){
            Session::put('billing_address',$request->all());

            if(PriceHelper::CheckDigital()){
                $shipping = [
                    "ship_first_name" => $request->bill_first_name,
                    "ship_last_name" => $request->bill_last_name,
                    "ship_email" => $request->bill_email,
                    "ship_phone" => $request->bill_phone,
                    "ship_company" => $request->bill_company,
                    "ship_address1" => $request->bill_address1,
                    "ship_address2" => $request->bill_address2,
                    "ship_zip" => $request->bill_zip,
                    "ship_city" => $request->bill_city,
                    "ship_country" => $request->bill_country,
                ];
            }else{
                $shipping = [
                    "ship_first_name" => $request->bill_first_name,
                    "ship_last_name" => $request->bill_last_name,
                    "ship_email" => $request->bill_email,
                    "ship_phone" => $request->bill_phone,
                ];
            }
            Session::put('shipping_address',$shipping);
        }else{
            Session::put('billing_address',$request->all());
            Session::forget('shipping_address');
        }

        if(Session::has('shipping_address')){
            return redirect()->route('front.checkout.payment');
        }else{
            return redirect()->route('front.checkout.shipping');
        }

    }


    public function shipping()
    {

        if(Session::has('shipping_address')){
            return redirect(route('front.checkout.payment'));
        }

        if (!Session::has('cart')) {
            return redirect(route('front.cart'));
        }
        $data['user'] = Auth::user();
        $cart = Session::get('cart');

        $total_tax = 0;
        $cart_total = 0;
        $total = 0;

        foreach($cart as $key => $item){

            $total += ($item['main_price'] + $item['attribute_price']) * $item['qty'];
            $cart_total = $total;
            $item = Item::findOrFail($key);
            if($item->tax){
                $total_tax += $item::taxCalculate($item);
            }
        }
        $shipping = [];
        if(ShippingService::whereStatus(1)->whereId(1)->whereIsCondition(1)->exists()){
            $shipping = ShippingService::whereStatus(1)->whereId(1)->whereIsCondition(1)->first();
            if($cart_total >= $shipping->minimum_price){
                $shipping = $shipping;
            }else{
                $shipping = [];
            }
        }

        if(!$shipping){
            $shipping = ShippingService::whereStatus(1)->where('id','!=',1)->first();
        }
        $discount = [];
        if(Session::has('coupon')){
            $discount = Session::get('coupon');
        }

        if (!PriceHelper::Digital()){
            $shipping = null;
        }

        $grand_total = ($cart_total + ($shipping?$shipping->price:0)) + $total_tax;
        $grand_total = $grand_total - ($discount ? $discount['discount'] : 0);
        $state_tax = Auth::check() && Auth::user()->state_id ? Auth::user()->state->price : 0;
        $grand_total = $grand_total + $state_tax;

        $total_amount = $grand_total;
        $data['cart'] = $cart;
        $data['cart_total'] = $cart_total;
        $data['grand_total'] = $total_amount;
        $data['discount'] = $discount;
        $data['shipping'] = $shipping;
        $data['tax'] = $total_tax;
        $data['payments'] = PaymentSetting::whereStatus(1)->get();
        return view('front.checkout.shipping',$data);
    }

    public function shippingStore(Request $request)
    {

        Session::put('shipping_address',$request->all());
        return redirect(route('front.checkout.payment'));
    }



    public function payment()
    {
        if(!Session::has('billing_address')){
            return redirect(route('front.checkout.billing'));
        }

        if(!Session::has('shipping_address')){
            return redirect(route('front.checkout.shipping'));
        }


        if (!Session::has('cart')) {
            return redirect(route('front.cart'));
        }
        $data['user'] = Auth::user();
        $cart = Session::get('cart');

        $total_tax = 0;
        $cart_total = 0;
        $total = 0;

        foreach($cart as $key => $item){

            $total += ($item['main_price'] + $item['attribute_price']) * $item['qty'];
            $cart_total = $total;
            $item = Item::findOrFail($key);
            if($item->tax){
                $total_tax += $item::taxCalculate($item);
            }
        }
        $shipping = [];
        if(ShippingService::whereStatus(1)->whereId(1)->whereIsCondition(1)->exists()){
            $shipping = ShippingService::whereStatus(1)->whereId(1)->whereIsCondition(1)->first();
            if($cart_total >= $shipping->minimum_price){
                $shipping = $shipping;
            }else{
                $shipping = [];
            }
        }

        if(!$shipping){
            $shipping = ShippingService::whereStatus(1)->where('id','!=',1)->first();
        }
        $discount = [];
        if(Session::has('coupon')){
            $discount = Session::get('coupon');
        }

        if (!PriceHelper::Digital()){
            $shipping = null;
        }

        $grand_total = ($cart_total + ($shipping?$shipping->price:0)) + $total_tax;
        $grand_total = $grand_total - ($discount ? $discount['discount'] : 0);
        $state_tax = Auth::check() && Auth::user()->state_id ? Auth::user()->state->price : 0;
        $grand_total = $grand_total + $state_tax;


        $total_amount = $grand_total;

        $data['cart'] = $cart;
        $data['cart_total'] = $cart_total;
        $data['grand_total'] = $total_amount;
        $data['discount'] = $discount;
        $data['shipping'] = $shipping;
        $data['tax'] = $total_tax;
        $data['payments'] = PaymentSetting::whereStatus(1)->get();
        return view('front.checkout.payment',$data);
    }

	public function checkout(PaymentRequest $request)
	{


        $input = $request->all();

        $checkout = false;
        $payment_redirect = false;
        $payment = null;

        if(Session::has('currency')){
            $currency = Currency::findOrFail(Session::get('currency'));
        }else{
            $currency = Currency::where('is_default',1)->first();
        }

        // use currency check
        $usd_supported = ['USD','EUR','AUD'];
        $paypal_supported = ['USD','EUR','AUD','BRL','CAD','HKD','JPY','MXN','NZD','PHP','GBP','RUB'];
        $paystack_supported = ['NGN'];
        switch ($input['payment_method']) {

            case 'Stripe':
                if(!in_array($currency->name,$usd_supported)){
                    Session::flash('error',__('Currency Not Supported'));
                    return redirect()->back();
                }
                $checkout = true;
                $payment = $this->stripeCheckout($input);
            break;

            case 'Paypal':
                if(!in_array($currency->name,$paypal_supported)){
                    Session::flash('error',__('Currency Not Supported'));
                    return redirect()->back();
                }
                $checkout = true;
                $payment_redirect = true;
                $payment = $this->paypalSubmit($input);
            break;


            case 'Mollie':
                if(!in_array($currency->name,$usd_supported)){
                    Session::flash('error',__('Currency Not Supported'));
                    return redirect()->back();
                }
                $checkout = true;
                $payment_redirect = true;
                $payment = $this->MollieSubmit($input);
            break;

            case 'Paystack':
                if(!in_array($currency->name,$paystack_supported)){
                    Session::flash('error',__('Currency Not Supported'));
                    return redirect()->back();
                }
                $checkout = true;
                $payment = $this->PaystackSubmit($input);

            break;

            case 'Bank':
                $checkout = true;
                $payment = $this->BankSubmit($input);
            break;

            case 'Cash On Delivery':
                $checkout = true;
                $payment = $this->cashOnDeliverySubmit($input);
            break;

        }



        if($checkout){
            if($payment_redirect){

                if($payment['status']){
                    return redirect()->away($payment['link']);
                }else{
                    Session::put('message',$payment['message']);
                    return redirect()->route('front.checkout.cancle');
                }
            }else{
                if($payment['status']){
                    return redirect()->route('front.checkout.success');
                }else{
                    Session::put('message',$payment['message']);
                    return redirect()->route('front.checkout.cancle');
                }
            }
        }else{
            return redirect()->route('front.checkout.cancle');
        }

	}
	
	public function stripeCheckout($input) {
	    require "stripe/vendor/autoload.php";
	    $data = PaymentSetting::whereUniqueKeyword('stripe')->first();
	    $paydata = $data->convertJsonData();
	    \Stripe\Stripe::setApiKey($paydata['secret']);
	    $cart = Session::get('cart');

        $total_tax = 0;
        $cart_total = 0;
        $total = 0;
        $option_price = 0;
        $name="";
        $line_items=[];
        foreach($cart as $key => $item){
            $name=$item['name'];
            $total += $item['main_price'] * $item['qty'];
            $option_price += $item['attribute_price'];
            $cart_total = $total + $option_price;
            $line_item=['price_data' => ['product_data' => ['name' =>$name ],'unit_amount' => PriceHelper::storePrice($item['main_price'])*100,'currency' => 'USD'],'quantity' => $item['qty'],'description' => $name];
            $item = Item::findOrFail($key);
            if($item->tax){
                $total_tax += $item::taxCalculate($item);
            }
            array_push($line_items,$line_item);
        }
        $shipping = [];
        if(ShippingService::whereStatus(1)->whereId(1)->whereIsCondition(1)->exists()){
            $shipping = ShippingService::whereStatus(1)->whereId(1)->whereIsCondition(1)->first();
            if($cart_total >= $shipping->minimum_price){
                $shipping = $shipping;
            }else{
                $shipping = [];
            }
        }

        if(!$shipping){
            $shipping = ShippingService::whereStatus(1)->where('id','!=',1)->first(); 
        }

        if (!PriceHelper::Digital()){
            $shipping = null;
        }
        
        $discount = [];
        if(Session::has('coupon')){
            $discount = Session::get('coupon');
        }
        $orderData['state'] =  $data['state_id'] ? json_encode(State::findOrFail($data['state_id']),true) : null;
        $grand_total = ($cart_total + ($shipping?$shipping->price:0)) + $total_tax;
        $grand_total = $grand_total - ($discount ? $discount['discount'] : 0);
        $grand_total += PriceHelper::StatePrce($data['state_id'],$cart_total);
        $total_amount = PriceHelper::setConvertPrice($grand_total);
        $orderData['cart'] = json_encode($cart,true);
        $orderData['discount'] = json_encode($discount,true);
        $orderData['shipping'] = json_encode($shipping,true);
        $orderData['tax'] = $total_tax;
        $orderData['state_price'] = PriceHelper::StatePrce($data['state_id'],$cart_total);
        $orderData['shipping_info'] = json_encode(Session::get('shipping_address'),true);
        $orderData['billing_info'] = json_encode(Session::get('billing_address'),true);
        $orderData['payment_method'] = 'Stripe';
        $orderData['user_id'] = (auth()->check()) ? auth()->user()->id : 0;
	    $checkout_session = \Stripe\Checkout\Session::create([ 
	        "payment_method_types"=> ["card","afterpay_clearpay"],
	        'shipping_address_collection' => [
              'allowed_countries' => ['AU'],
            ],
            'shipping_options' => [
              [
                'shipping_rate_data' => [
                  'type' => 'fixed_amount',
                  'fixed_amount' => [
                    'amount' => 0,
                    'currency' => 'usd',
                  ],
                  'display_name' => 'Free shipping',
                  // Delivers between 5-7 business days
                  'delivery_estimate' => [
                    'minimum' => [
                      'unit' => 'business_day',
                      'value' => 5,
                    ],
                    'maximum' => [
                      'unit' => 'business_day',
                      'value' => 7,
                    ],
                  ]
                ]
              ],
              [
                'shipping_rate_data' => [
                  'type' => 'fixed_amount',
                  'fixed_amount' => [
                    'amount' => 1500,
                    'currency' => 'usd',
                  ],
                  'display_name' => 'Next day air',
                  // Delivers in exactly 1 business day
                  'delivery_estimate' => [
                    'minimum' => [
                      'unit' => 'business_day',
                      'value' => 1,
                    ],
                    'maximum' => [
                      'unit' => 'business_day',
                      'value' => 1,
                    ],
                  ]
                ]
              ],
            ],
            'line_items' => [$line_items], 
            'customer_email' => auth()->user()->email, 
            'mode' => 'payment', 
            'success_url' => route('front.checkout.stripe.redirect'), 
            'cancel_url' => route('front.checkout.cancle'), 
        ]);
        Session::put('order_data',$orderData);
        Session::put('order_payment_id', $checkout_session->id);
        Session::save();
        header("HTTP/1.1 303 See Other");
        header("Location: " . $checkout_session->url);
	    die();
	    
	}
	public function stripeNotify(Request $request){
    
        $responseData = $request->all();
        if(Session::has('order_payment_id')){
            $payment = $this->stripemethod($responseData);
            if($payment['status']){
                return redirect()->route('front.checkout.success');
            }else{
                Session::put('message',$payment['message']);
                return redirect()->route('front.checkout.cancle');
            }
        }else{
            return redirect()->route('front.checkout.cancle');
        }
        

    }
    
    public function stripemethod($responseData) {
        require "stripe/vendor/autoload.php";
        $data = PaymentSetting::whereUniqueKeyword('stripe')->first();
	    $paydata = $data->convertJsonData();
	    \Stripe\Stripe::setApiKey($paydata['secret']);
        $orderData = Session::get('order_data');
        /** Get the payment ID before session clear **/
        $payment_id = Session::get('order_payment_id');
        try { 
            $checkout_session = \Stripe\Checkout\Session::retrieve($payment_id); 
        } catch(Exception $e) {  
            $api_error = $e->getMessage();  
        } 
        if(empty($api_error) && $checkout_session){
            try {
                $paymentIntent = \Stripe\PaymentIntent::retrieve($checkout_session->payment_intent); 
            } catch (\Stripe\Exception\ApiErrorException $e) { 
                $api_error = $e->getMessage(); 
            } 
            try { 
                $customer = \Stripe\Customer::retrieve($checkout_session->customer); 
            } catch (\Stripe\Exception\ApiErrorException $e) { 
                $api_error = $e->getMessage(); 
            }
            
            if(empty($api_error) && $paymentIntent){
                if(!empty($paymentIntent) && $paymentIntent->status == 'succeeded'){
                    $cart = Session::get('cart');
                    $user = Auth::user();
                    $total_tax = 0;
                    $cart_total = 0;
                    $total = 0;
                    $option_price = 0;
                    foreach($cart as $key => $item){
            
                        $total += $item['main_price'] * $item['qty'];
                        $option_price += $item['attribute_price'];
                        $cart_total = $total + $option_price;
                        $item = Item::findOrFail($key);
                        if($item->tax){
                            $total_tax += $item->tax->value;
                        }
                    }
                    $shipping = [];
                    if(ShippingService::whereStatus(1)->whereId(1)->whereIsCondition(1)->exists()){
                        $shipping = ShippingService::whereStatus(1)->whereId(1)->whereIsCondition(1)->first();
                        if($cart_total >= $shipping->minimum_price){
                            $shipping = $shipping;
                        }else{
                            $shipping = [];
                        }
                    }
            
                    if(!$shipping){
                        $shipping = ShippingService::whereStatus(1)->where('id','!=',1)->first(); 
                    }
                    $discount = [];
                    if(Session::has('coupon')){
                        $discount = Session::get('coupon');
                    }
        
                    $grand_total = ($cart_total + ($shipping?$shipping->price:0)) + $total_tax;
                    $grand_total = $grand_total - ($discount ? $discount['discount'] : 0);
                    $total_amount = PriceHelper::setConvertPrice($grand_total);
                    $orderData['cart'] = json_encode($cart,true);
                    $orderData['discount'] = json_encode($discount,true);
                    $orderData['shipping'] = json_encode($shipping,true);
                    $orderData['tax'] = $total_tax;
                    $orderData['shipping_info'] = json_encode(Session::get('shipping_address'),true);
                    $orderData['billing_info'] = json_encode(Session::get('billing_address'),true);
                    $orderData['payment_method'] = 'Paypal';
                    $orderData['user_id'] = isset($user) ? $user->id : 0;
                    $orderData['txnid'] =  $payment_id;
                    $orderData['payment_status'] = 'Paid';
                    $orderData['transaction_number'] = Str::random(10);
                    $orderData['currency_sign'] = PriceHelper::setCurrencySign();
                    $orderData['currency_value'] = PriceHelper::setCurrencyValue();
                    $orderData['order_status'] = 'Pending';
                    $order = Order::create($orderData);
                    PriceHelper::Transaction($order->id,$order->transaction_number,EmailHelper::getEmail(),PriceHelper::OrderTotal($order,'trns'));
                    PriceHelper::LicenseQtyDecrese($cart);
                    PriceHelper::LicenseQtyDecrese($cart);
                    
                    if(Session::has('copon')){
                        $code = PromoCode::find(Session::get('copon')['code']['id']);
                        $code->no_of_times--;
                        $code->update();
                    }
        
                    if($discount){
                        $coupon_id = $discount['code']['id'];
                        $get_coupon = PromoCode::findOrFail($coupon_id);
                        $get_coupon->no_of_times -= 1;
                        $get_coupon->update();
                    }
        
                    TrackOrder::create([
                        'title' => 'Pending',
                        'order_id' => $order->id,
                    ]);
        
                    Notification::create([
                        'order_id' => $order->id
                    ]);
                    
                    $setting = Setting::first();
                    if($setting->is_twilio == 1){
                        // message
                        $sms = new SmsHelper();
                        $user_number = json_decode($order->billing_info,true)['bill_phone'];
                        if($user_number){
                            $sms->SendSms($user_number,"'purchase'",$order->transaction_number);
                        }
                    }
        
                    $emailData = [
                        'to' => EmailHelper::getEmail(),
                        'type' => "Order",
                        'user_name' => isset($user) ? $user->displayName() : Session::get('billing_address')['bill_first_name'],
                        'order_cost' => $total_amount,
                        'transaction_number' => $order->transaction_number,
                        'site_title' => Setting::first()->title,
                    ];
        
                    $email = new EmailHelper();
                    $email->sendTemplateMail($emailData);
        
                    Session::put('order_id',$order->id);
                    Session::forget('cart');
                    Session::forget('discount');
                    Session::forget('order_data');
                    Session::forget('order_payment_id');
                    Session::forget('coupon');
                    return [
                        'status' => true
                    ];
                    
                }else{
                    $statusMsg = "Transaction has been failed!";
                } 
            }else{
                $statusMsg = "Unable to fetch the transaction details! $api_error";  
            } 
        }else{ 
            $statusMsg = "Invalid Transaction! $api_error";  
        }
        return [
                'status' => false,
                'message' => $statusMsg
            ];

    }

	public function paymentRedirect(Request $request)
	{
        $responseData = $request->all();
        if(Session::has('order_payment_id')){
            $payment = $this->paypalNotify($responseData);
            if($payment['status']){
                return redirect()->route('front.checkout.success');
            }else{
                Session::put('message',$payment['message']);
                return redirect()->route('front.checkout.cancle');
            }
        }else{
            return redirect()->route('front.checkout.cancle');
        }
    }

	public function mollieRedirect(Request $request)
	{

        $responseData = $request->all();

        $payment = Mollie::api()->payments()->get(Session::get('payment_id'));
        $responseData['payment_id'] = $payment->id;
        if($payment->status == 'paid'){
            $payment = $this->mollieNotify($responseData);
            if($payment['status']){
                return redirect()->route('front.checkout.success');
            }else{
                Session::put('message',$payment['message']);
                return redirect()->route('front.checkout.cancle');
            }
        }else{
            return redirect()->route('front.checkout.cancle');
        }

    }

	public function paymentSuccess()
	{
        if(Session::has('order_id')){
            $order_id = Session::get('order_id');
            $order = Order::find($order_id);
            $cart = json_decode($order->cart, true);
            $setting = Setting::first();
            if($setting->is_twilio == 1){
                // message
                $sms = new SmsHelper();
                $user_number = $order->user->phone;
                if($user_number){
                    $sms->SendSms($user_number,"'purchase'");
                }
            }
            return view('front.checkout.success',compact('order','cart'));
        }
        return redirect()->route('front.index');

	}



	public function paymentCancle()
	{
        $message = '';
        if(Session::has('message')){
            $message = Session::get('message');
            Session::forget('message');
        }else{
            $message = __('Payment Failed!');
        }
        Session::flash('error',$message);
        return redirect()->route('front.checkout.billing');
	}

    public function stateSetUp($state_id)
	{

        if (!Session::has('cart')) {
            return redirect(route('front.cart'));
        }

        $cart = Session::get('cart');
        $total_tax = 0;
        $cart_total = 0;
        $total = 0;
        foreach($cart as $key => $item){

            $total += ($item['main_price'] + $item['attribute_price']) * $item['qty'];
            $cart_total = $total;
            $item = Item::findOrFail($key);
            if($item->tax){
                $total_tax += $item::taxCalculate($item);
            }
        }

        $shipping = [];
        if(ShippingService::whereStatus(1)->whereId(1)->whereIsCondition(1)->exists()){
            $shipping = ShippingService::whereStatus(1)->whereId(1)->whereIsCondition(1)->first();
            if($cart_total >= $shipping->minimum_price){
                $shipping = $shipping;
            }else{
                $shipping = [];
            }
        }

        if(!$shipping){
            $shipping = ShippingService::whereStatus(1)->where('id','!=',1)->first();
        }
        $discount = [];
        if(Session::has('coupon')){
            $discount = Session::get('coupon');
        }

        $grand_total = ($cart_total + ($shipping?$shipping->price:0)) + $total_tax;
        $grand_total = $grand_total - ($discount ? $discount['discount'] : 0);

        $state_price = 0;
        if($state_id){
            $state = State::findOrFail($state_id);
            if($state->type == 'fixed'){
                $state_price = $state->price;
            }else{
                $state_price = ($cart_total * $state->price) / 100;
            }

        }else{
            if(Auth::check() && Auth::user()->state_id){
                $state = Auth::user()->state;
                if($state->type == 'fixed'){
                    $state_price = $state->price;
                }else{
                    $state_price = ($cart_total * $state->price) / 100;
                }
            }else{
                $state_price = 0;
            }
        }

        $total_amount = $grand_total + $state_price;

        $data['state_price'] = PriceHelper::setCurrencyPrice($state_price);
        $data['grand_total'] = PriceHelper::setCurrencyPrice($total_amount);

        return response()->json($data);

    }

}
