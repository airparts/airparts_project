@extends('master.front')
@section('meta')
<meta name="keywords" content="{{$setting->meta_keywords}}">
<meta name="description" content="{{$setting->meta_description}}">
@endsection
@section('title')
    {{__('Products')}}
@endsection

@section('content')
@php
    function renderStarRating($rating, $maxRating = 5)
    {
        $fullStar = "<i class = 'far fa-star filled'></i>";
        $halfStar = "<i class = 'far fa-star-half filled'></i>";
        $emptyStar = "<i class = 'far fa-star'></i>";
        $rating = $rating <= $maxRating ? $rating : $maxRating;

        $fullStarCount = (int) $rating;
        $halfStarCount = ceil($rating) - $fullStarCount;
        $emptyStarCount = $maxRating - $fullStarCount - $halfStarCount;

        $html = str_repeat($fullStar, $fullStarCount);
        $html .= str_repeat($halfStar, $halfStarCount);
        $html .= str_repeat($emptyStar, $emptyStarCount);
        $html = $html;
        return $html;
    }
@endphp
    <!-- Page Title-->
<div class="about-us-bottom-area section-top-gap-100">
  <div class="section-content-gap">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-lg-4 col-md-4 col-sm-12 col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> Shop <span class="red-circle"></span>
                        </h3>  
                    </div>
                    <div class="col-lg-8 col-md-8 col-sm-12 col-12 pl-5 text-right">
                        <button class="btn btn-danger mb-1">Filter</button>
                        <button class="btn btn-danger-o mb-1">By Category</button>
                        <button class="btn btn-danger-o mb-1">By Condition</button>
                        <button class="btn btn-danger-o mb-1">By Price Range</button>
                        <button class="btn btn-danger-o mb-1">By Item Location</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
    <form action="" method="post" role="form">
      <div class="container-fluid pr-3 pl-3">
          <div class="row m-0">
            <div class="col-xl-3 col-lg-2 col-md-4 col-sm-12 col-12">
              <div class="form-group">
                <h6 class="font-weight-bolder">2003 BMW Z4</h6>
                <p class="text-secondary"><i class="fa fa-arrow-right"></i> Accessories and Parts</p>
              </div>
            </div>
            <div class="col-xl-2 col-lg-2 col-md-4 col-sm-6 col-12 mt-6">
                <div class="form-group text-right">
                    <button class="btn btn-danger-o btn-sm">Change Vehicle</button>
                </div>
            </div>
            <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12 mt-5">
                <div class="d-flex">
                    <h6 class="w100x mt-2 font-500">Sort by</h6>
                    <select class="form-control" name="model" style="display: none;">
                        <option value="">Best Selling</option>
                        <option value="">Best Rating</option>
                        <option value="">Price</option>
                    </select><div class="nice-select form-control" tabindex="0"><span class="current">Best Selling</span><ul class="list"><li data-value="" class="option selected">Best Selling</li><li data-value="" class="option">Best Rating</li><li data-value="" class="option">Price</li></ul></div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-5 col-md-12 col-sm-12 col-12 mt-5">
                <div class="d-flex justify-content-end">
                    <h6 class="w100x mt-2 font-500">Show Items</h6>
                    <button class="btn btn-danger mr-1">20</button>
                    <button class="btn btn-danger-o mr-1">30</button>
                    <button class="btn btn-danger-o mr-1">40</button>
                    <button class="btn btn-danger-o mr-1">50</button>
                    <button class="btn btn-secondary mr-1"><i class="fa fa-th"></i></button>
                    <button class="btn btn-secondary"><i class="fa fa-list-ul"></i></button>
                </div>
            </div>
            <div class="col-12 mt-5">
                <div class="tab-content tab-animate-zoom">
                    <div class="tab-pane active show" id="drive_and_car">
                        <div class="product-default-slider row">
                            <div class="col-lg-12 col-md-12 col-sm-12">
                                <div class="row col-12">
                                  @if($items->count() > 0)
                                      @foreach ($items as $item)
                                       <div class="product-default-single col-xl-3 col-lg-4 col-md-6 col-sm-12">
                                          <div class="product-wrap border-around">
                                              <div class="product-img-warp">
                                                  <a href="{{route('front.product',$item->slug)}}" class="product-default-img-link">
                                                      <img src="{{asset('assets/images/'.$item->thumbnail)}}" alt="Product" class="product-default-img img-fluid">
                                                  </a>
                                              </div>
                                              <div class="product-default-content">
                                                  <p class="mb-1 op06"><span class="text-red"><strong>{{ __('Category') }}: </strong></span><a href="{{route('front.catalog').'?category='.$item->category->slug}}">
                                                        {{$item->category->name}}
                                                    </a></p>
                                                  <h6 class="product-default-link"><a href="{{route('front.product',$item->slug)}}">{{ strlen(strip_tags($item->name)) > 35 ? substr(strip_tags($item->name), 0, 35) : strip_tags($item->name) }}</a></h6>
                                                  <div class="product_stars d-flex">
                                                      {!! renderStarRating($item->reviews->avg('rating')) !!}
                                                    </div>
                                                    <div class="row mt-1">
                                                        <div class="col-xl-6 col-lg-12 col-md-6 col-6">
                                                        @if((!$item->is_stock()))
                                                        <h6 class="text-red">{{__('out of stock')}}</h6>
                                                        @else
                                                        <h4 class="text-red"><strong>
                                                            {{PriceHelper::grandCurrencyPrice($item)}}
                                                        </strong></h4>
                                                        @endif
                                                        </div>
                                                        <div class="col-xl-6 col-lg-12 col-md-6 col-6 d-flex pt-1 justify-content-end">
                                                          <img class="icon-material-location-on" width="15" height="18" src="{{ asset('assets/assets/images/icon/icon-material-location-on-10@1x.png') }}">
                                                          <div class="place barlow-medium-black-15px-2">{{ __($item->country) }}</div>
                                                          <img class="group-390" width="20" height="20" src="{{ asset('assets/assets/images/icon/group-390-11@1x.png') }}">
                                                        </div>
                                                        <div class="col-12 mt-2">
                                                            <a data-target="{{ $item->id }}" href="javascript:void(0);" class="btn btn-red btn-block add_to_single_cart">Add to Cart</a>
                                                        </div>
                                                    </div>
                                                </div>
                                          </div>
                                          <a class="product_wish_icon wishlist_store" href="javascript:void(0);" style="right:45px;" data-href="{{route('user.wishlist.store',$item->id)}}"><i class="icon-heart"></i></a>
                                      </div>
                                      @endforeach
                                  @else
                                      <div class="col-lg-12">
                                          <div class="card">
                                              <div class="card-body text-center">
                                                  <h4 class="h4 mb-0">{{ __('No Product Found') }}</h4>
                                              </div>
                                          </div>
                                      </div>
                                  @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {{ $items->links('vendor.pagination.custom') }}
          </div>
 
      </div>
  </div>
    
</div>
@endsection

