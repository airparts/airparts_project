@extends('master.front')

@section('title')
 {{ $item->name}}
@endsection

@section('meta')
<meta name="keywords" content="{{$item->meta_keywords}}">
<meta name="description" content="{{$item->meta_description}}">
@endsection

@section('content')
@php
function renderStarRating($rating,$maxRating=5) {

    $fullStar = "<i class = 'far fa-star filled'></i>";
    $halfStar = "<i class = 'far fa-star-half filled'></i>";
    $emptyStar = "<i class = 'far fa-star'></i>";
    $rating = $rating <= $maxRating?$rating:$maxRating;

    $fullStarCount = (int)$rating;
    $halfStarCount = ceil($rating)-$fullStarCount;
    $emptyStarCount = $maxRating -$fullStarCount-$halfStarCount;

    $html = str_repeat($fullStar,$fullStarCount);
    $html .= str_repeat($halfStar,$halfStarCount);
    $html .= str_repeat($emptyStar,$emptyStarCount);
    $html = $html;
    return $html;
}
@endphp
<div class="about-us-bottom-area section-top-gap-100">
  <div class="section-content-gap">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> {{ __('Product Details') }} <span class="red-circle"></span>
                        </h3>  
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
    <input type="hidden" id="item_id" value="{{$item->id}}">
    <input type="hidden" id="demo_price" value="{{PriceHelper::setConvertPrice($item->discount_price)}}">
    <input type="hidden" value="{{PriceHelper::setCurrencySign()}}" id="set_currency">
    <input type="hidden" value="{{PriceHelper::setCurrencyValue()}}" id="set_currency_val">
    <input type="hidden" value="{{$setting->currency_direction}}" id="currency_direction">
      <div class="container">
          <div class="row m-0">
            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
              <div class="hero-area">
                  <div class="hero-area-wrapper hero-slider-dots fix-slider-dots">
                      <div class="hero-area-single">
                          <div class="hero-area-bg">
                              <img class="hero-img" src="{{asset('assets/images/'.$item->photo)}}" alt="">
                          </div>
                      </div>
                      @foreach ($galleries as $key => $gallery)
                      <div class="hero-area-single">
                          <div class="hero-area-bg">
                              <img class="hero-img" src="{{asset('assets/images/'.$gallery->photo)}}" alt="">
                          </div>
                      </div>
                      @endforeach
                  </div>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
              <h3 class="font-weight-bold">{{$item->name}}</h3>
              <div class="inline-form-group d-flex mt-2 mb-2">
                {!!renderStarRating($item->reviews->avg('rating'))!!}
                <span class="text-secondary ml-4">({{ $item->reviews->count() }} {{ __('Reviews') }})</span>
              </div>
              <div class="form-group d-flex flex-column">
                <label class="control-label">
                  <input type="radio" name="" class="form-check-input"> 
                  <span>4 Payments of $50 with <img src="{{ asset('assets/img/afterpay.png') }}" width="70px"></span>
                </label>
                <label class="control-label">
                  <input type="radio" name="" class="form-check-input"> 
                  <span>Pay later, from $10 per month with <img src="{{ asset('assets/img/zipmoney.png') }}" width="90px"></span>
                </label>
              </div>
              <div class="form-group mt-3">
                <h4 class="font-weight-bold"><i class="fa fa-check-circle text-red"></i> <a href="{{route('front.catalog').'?category='.$item->category->slug}}">{{$item->category->name}}</a></h4>
              </div>
              <div class="form-group">
                <div class="row mr-0">
                    @if($item->brand)
                  <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <h6 class="font-weight-bold"><i class="fa fa-tag text-red"></i> {{ $item->brand->name }}</h6>
                    <label class="control-label ml-4">
                        {!! $item->sort_details !!}
                    </label>
                  </div>
                  @endif
                  <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="form-group float-right">
                      <h6>{{ __('Share this') }}</h6>
                      <div class="d-flex">
                        <a class="" href="https://facebook.com/">
                            <i class="text-red fab fa-facebook mr-3 font18"></i>
                        </a>
                        <a class="" href="https://twitter.com/">
                            <i class="text-red fab fa-twitter mr-3 font18"></i>
                        </a>
                        <a class="" href="https://instagram.com/">
                            <i class="text-red fab fa-instagram font18"></i>
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div class="form-group mt-3">
                <h4 class="font-weight-bold"><i class="fa fa-commenting-o text-red"></i> Questions &amp; Answers</h4>
                <p class="ml-5">If you have any question related to product, please don't hesitate to ask us.<br>We will be happy to help you.</p>
                <button class="btn btn-danger-o mt-2 ml-5">Ask a Question</button>
              </div>
              @if ($item->is_stock())
                <div class="form-group mt-3">
                    <h2 class="font-weight-bolder mb-4"> 
                        <span id="main_price" class="main-price">{{PriceHelper::grandCurrencyPrice($item)}}</span>
                        <sub class="text-secondary ml-3">incl. GST</sub>
                    </h2>
                    
                </div>
                @else
                    <span class="text-danger d-inline-block">{{__('Out of stock')}}</span>
                @endif
              <div class="form-group mt-5">
                <div class="row mr-0">
                  <div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 col-12 text-center qtySelector product-quantity">
                    <button class="btn btn-danger-o mb-1 decreaseQty subclick"><i class="fa fa-minus"></i></button>
                    <input type="button" style="max-width: 50px;" readonly class="btn btn-danger mb-1 qtyValue cart-amount" value="1">
                    <button class="btn btn-danger-o mb-1 increaseQty addclick"><i class="fa fa-plus"></i></button>
                    <input type="hidden" value="3333" id="current_stock">
                  </div>
                  <div class="col-xl-4 col-lg-6 col-md-12 col-sm-12 col-12 text-center">
                    @if ($item->is_stock())
                    <button class="btn-block btn btn-danger mb-1" id="add_to_cart">{{ __('Add to Cart') }}</button>
                    @else
                    <button class="btn btn-danger mb-1"><i class="icon-bag"></i><span>{{__('Out of stock')}}</span></button>
                    @endif
                  </div>
                  <div class="col-xl-4 col-lg-12 col-md-12 col-sm-12 col-12 text-center">

                    <a href="{{route('user.wishlist.store',$item->id)}}" class="btn btn-danger-o mb-1 wishlist_store wishlist_text"><i class="fas fa-heart"></i>
                        @if (Auth::check() && App\Models\Wishlist::where('user_id',Auth::user()->id)->where('item_id',$item->id)->exists())
                        <span>{{__('Added To Wishlist')}}</span>
                        @else
                        <span class="wishlist1">{{__('Wishlist')}}</span>
                        <span class="wishlist2 d-none">{{__('Added To Wishlist')}}</span>
                        @endif
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
              <div class=" padding-top-3x mb-3" id="details">
            <div class="col-lg-12">
            <ul class="nav nav-tabs" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link active" id="description-tab" data-bs-toggle="tab" data-bs-target="#description" type="button" role="tab" aria-controls="description" aria-selected="true">{{__('Descriptions')}}</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="specification-tab" data-bs-toggle="tab" data-bs-target="#specification" type="button" role="tab" aria-controls="specification" aria-selected="false">{{__('Specifications')}}</a>
                </li>
            </ul>
            <div class="tab-content card">
                <div class="tab-pane fade show active" id="description" role="tabpanel" aria-labelledby="description-tab"">
                {!! $item->details !!}
                </div>
                <div class="tab-pane fade show" id="specification" role="tabpanel" aria-labelledby="specification-tab">
                <div class="comparison-table">
                    <table class="table table-bordered">
                        <thead class="bg-secondary">
                        </thead>
                        <tbody>
                        <tr class="bg-secondary">
                            <th class="text-uppercase text-white">{{__('Specifications')}}</th>
                            <td><span class="text-medium text-white">{{__('Descriptions')}}</span></td>
                        </tr>
                        @if($sec_name)
                        @foreach(array_combine($sec_name,$sec_details) as  $sname => $sdetail)
                        <tr>
                            <th>{{$sname}}</th>
                            <td>{{$sdetail}}</td>
                        </tr>
                        @endforeach
                        @else
                        <tr class="text-center">
                            <td colspan="2">{{__('No Specifications')}}</td>
                            </tr>
                        @endif
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
            </div>
        </div>
          </div>
      </div>
  </div>
    
</div>
<div class="section-content-gap section-top-gap-100">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> People also bought <span class="red-circle"></span>
                        </h3>  
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="post_ad-wrapper content-wrapper">
  <div class="container-fluid">
    <div class="row col-12 m-0">
        @foreach ($related_items as $item)
        <div class="product-default-single col-xl-3 col-lg-4 col-md-6 col-sm-12">
          <div class="product-wrap border-around">
              <div class="product-img-warp">
                  <a href="{{route('front.product',$item->slug)}}" class="product-default-img-link">
                      <img src="{{asset('assets/images/'.$item->thumbnail)}}" alt="Product" class="product-default-img img-fluid">
                  </a>
              </div>
              <div class="product-default-content">
                  <p class="mb-1 op06"><span class="text-red"><strong>{{ __('Category') }}: </strong></span><a href="{{route('front.catalog').'?category='.$item->category->slug}}">
                        {{$item->category->name}}
                    </a></p>
                  <h6 class="product-default-link"><a href="{{route('front.product',$item->slug)}}">{{ strlen(strip_tags($item->name)) > 35 ? substr(strip_tags($item->name), 0, 35) : strip_tags($item->name) }}</a></h6>
                  <div class="product_stars d-flex">
                      {!! renderStarRating($item->reviews->avg('rating')) !!}
                    </div>
                    <div class="row mt-1">
                        <div class="col-xl-6 col-lg-12 col-md-6 col-6">
                        @if((!$item->is_stock()))
                        <h6 class="text-red">{{__('out of stock')}}</h6>
                        @else
                        <h4 class="text-red"><strong>
                            {{PriceHelper::grandCurrencyPrice($item)}}
                        </strong></h4>
                        @endif
                        </div>
                        <div class="col-xl-6 col-lg-12 col-md-6 col-6 d-flex pt-1 justify-content-end">
                          <img class="icon-material-location-on" width="15" height="18" src="{{ asset('assets/assets/images/icon/icon-material-location-on-10@1x.png') }}">
                          <div class="place barlow-medium-black-15px-2">{{ __($item->country) }}</div>
                          <img class="group-390" width="20" height="20" src="{{ asset('assets/assets/images/icon/group-390-11@1x.png') }}">
                        </div>
                        <div class="col-12 mt-2">
                            <a data-target="{{ $item->id }}" href="javascript:void(0);" class="btn btn-red btn-block add_to_single_cart">Add to Cart</a>
                        </div>
                    </div>
                </div>
          </div>
          <a class="product_wish_icon wishlist_store" href="javascript:void(0);" style="right:45px;" data-href="{{route('user.wishlist.store',$item->id)}}"><i class="icon-heart"></i></a>
      </div>
        @endforeach 
    </div>
  </div>
</div>
@endsection
