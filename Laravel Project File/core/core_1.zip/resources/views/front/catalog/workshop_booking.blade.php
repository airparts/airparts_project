@extends('master.front')

@section('title')
 { $setting->home_page_title }} - WorkShop Booking
@endsection
@section('styleplugins')
@endsection

@section('content')
<div class="about-us-bottom-area section-top-gap-100">
  <div class="section-content-gap">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> Workshop Booking <span class="red-circle"></span>
                        </h3>  
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
    <form action="" method="get" role="form">
      <div class="container-fluid pr-3 pl-3">
          <div class="row m-0">
            <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
              <div class="form-group">
                <h6 class="font-weight-bolder">Search by Location</h6>
                <input type="text" name="location" class="form-control" placeholder="Workshop Location">
              </div>
            </div>
            <div class="col-xl-1 col-lg-1 col-md-3 col-sm-6 col-6 mt-12">
                <div class="form-group text-right">
                    <button type="submit" class="btn btn-danger">Search</button>
                </div>
            </div>
            <div class="col-xl-7 col-lg-7 col-md-5 col-sm-6 col-6 mt-12">
                <div class="form-group text-left">
                    <button type="button" class="btn btn-danger" onclick="getLocation()">Use Current Location</button>
                </div>
            </div>
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mt-5">
              <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                  <div class="panel panel-default">
                      <div class="panel-heading" role="tab" id="headingOne">
                          <h6 class="font-weight-bold panel-title"> 
                            <a data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"> Refine by Workshop Fitting Services  </a> </h6>
                      </div>
                      <div id="collapseOne" class="panel-collapse collapse in show" role="tabpanel" aria-labelledby="headingOne">
                          <div class="panel-body mt-5">
                            <div class="row">
                              <div class="col-xl-2 col-lg-4 col-md-4 col-sm-6 col-12 d-flex flex-column">
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Car Battery</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Exterior Plastics</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Wheel Covers</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>L &amp; P Plate Holder</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Aircorn Clean Sanitise</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Engine Oil</span>
                                </label>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-12 d-flex flex-column">
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Bulb</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Steering Wheel Covers</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Window Shades</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Blind Spot Mirros</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>In Car Tech Accessory Setup</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Engine Treatment</span>
                                </label>
                              </div>
                              <div class="col-xl-2 col-lg-4 col-md-4 col-sm-6 col-12 d-flex flex-column">
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Wipers</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Seat Belt Buddies</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Spare Wheel Covers</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Suport Strut</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Child Restraints</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Fuel Treatment</span>
                                </label>
                              </div>
                              <div class="col-xl-2 col-lg-4 col-md-4 col-sm-6 col-12 d-flex flex-column">
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Roof Racks</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Floor Mats</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Number Plate Frames</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Washer Fluid Top Up</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Air Filter</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Assembly Service</span>
                                </label>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-12 d-flex flex-column">
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Seat Covers</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Dash Mats</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Number Plate Frames Screws</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Windscreen</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="fitting_service" class="form-check-input"> 
                                  <span>Cabin Air Filter</span>
                                </label>
                              </div>
                            </div>
                          </div>
                      </div>
                  </div>
              </div>
            </div>

            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12 mt-5">
              <div class="panel-group" id="accordiontwo" role="tablist" aria-multiselectable="true">
                  <div class="panel panel-default">
                      <div class="panel-heading" role="tab" id="headingTwo">
                          <h6 class="font-weight-bold panel-title"> 
                            <a data-toggle="collapse" data-parent="#accordiontwo" href="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo"> Refine by Other Services  </a> </h6>
                      </div>
                      <div id="collapseTwo" class="panel-collapse collapse in show" role="tabpanel" aria-labelledby="headingTwo">
                          <div class="panel-body mt-5">
                            <div class="row">
                              <div class="col-xl-2 col-lg-4 col-md-4 col-sm-6 col-12 d-flex flex-column">
                                <label class="control-label">
                                  <input type="radio" name="other_service" class="form-check-input"> 
                                  <span>Paint Mixing</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="other_service" class="form-check-input"> 
                                  <span>Oil Recycling</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="other_service" class="form-check-input"> 
                                  <span>Nitrogen Tyre Inflation</span>
                                </label>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-12 d-flex flex-column">
                                <label class="control-label">
                                  <input type="radio" name="other_service" class="form-check-input"> 
                                  <span>Vehicle Health Checks</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="other_service" class="form-check-input"> 
                                  <span>Engine Oil Level Checks</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="other_service" class="form-check-input"> 
                                  <span>Child Restraint Inspection</span>
                                </label>
                              </div>
                              <div class="col-xl-2 col-lg-4 col-md-4 col-sm-6 col-12 d-flex flex-column">
                                <label class="control-label">
                                  <input type="radio" name="other_service" class="form-check-input"> 
                                  <span>Diagnostic Scanning</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="other_service" class="form-check-input"> 
                                  <span>Engine Oil Testing</span>
                                </label>
                              </div>
                              <div class="col-xl-2 col-lg-4 col-md-4 col-sm-6 col-12 d-flex flex-column">
                                <label class="control-label">
                                  <input type="radio" name="other_service" class="form-check-input"> 
                                  <span>Battery Charging</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="other_service" class="form-check-input"> 
                                  <span>Widescreen Cleaning</span>
                                </label>
                              </div>
                              <div class="col-xl-3 col-lg-4 col-md-4 col-sm-6 col-12 d-flex flex-column">
                                <label class="control-label">
                                  <input type="radio" name="other_service" class="form-check-input"> 
                                  <span>Battery Testing</span>
                                </label>
                                <label class="control-label">
                                  <input type="radio" name="other_service" class="form-check-input"> 
                                  <span>Widescreen Repair</span>
                                </label>
                              </div>
                            </div>
                          </div>
                      </div>
                  </div>
              </div>
            </div>
            
            
          </div>

      </div>
    </form>
  </div>
  <div class="section-content-gap section-top-gap-100">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> Affliated Workshops <span class="red-circle"></span>
                        </h3>  
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-12 pl-5 text-right">
                        <a href="{{ url()->current() }}" class="btn btn-danger-o">View all <i class="fa fa-arrow-right"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
      <div class="container">
        <div class="row m-0">
          <div class="col-lg-4 col-md-6 col-sm-12 col-12">
            <div class="row">
              <div class="col-lg-5 col-md-5 col-sm-5 col-12 mb-1">
                <img src="{{ asset('assets/img/mask-group-14@1x.png') }}" class="img-responsive" width="100%" >
              </div>
              <div class="col-lg-7 col-md-7 col-sm-7 col-12">
                <h6 class="font-weight-bold">AirParts North Parratmatta</h6>
                <p><strong><i class="fa fa-map-marker text-red mr-1 font18"></i></strong> 2 windsor road Norht Parramatta NSW, AU 2151</p>
                <p><i class="fa fa-phone text-red mr-1 font18"></i> (02) 9683 4188</p>
                <span class=""><a href="" class="font-weight-bold text-red text-underline">View Details</a></span>
              </div>
            </div>
            <div class="row mt-3">
              <div class="col-lg-5 col-md-5 col-sm-5 col-12 mb-1">
                <img src="{{ asset('assets/img/mask-group-15@1x.png') }}" class="img-responsive" width="100%" >
              </div>
              <div class="col-lg-7 col-md-7 col-sm-7 col-12">
                <h6 class="font-weight-bold">AirParts North Parratmatta</h6>
                <p><strong><i class="fa fa-map-marker text-red mr-1 font18"></i></strong> 2 windsor road Norht Parramatta NSW, AU 2151</p>
                <p><i class="fa fa-phone text-red mr-1 font18"></i> (02) 9683 4188</p>
                <span class=""><a href="" class="font-weight-bold text-red text-underline">View Details</a></span>
              </div>
            </div>
            <div class="row mt-3">
              <div class="col-lg-5 col-md-5 col-sm-5 col-12 mb-1">
                <img src="{{ asset('assets/img/mask-group-16@1x.png') }}" class="img-responsive" width="100%" >
              </div>
              <div class="col-lg-7 col-md-7 col-sm-7 col-12">
                <h6 class="font-weight-bold">AirParts North Parratmatta</h6>
                <p><strong><i class="fa fa-map-marker text-red mr-1 font18"></i></strong> 2 windsor road Norht Parramatta NSW, AU 2151</p>
                <p><i class="fa fa-phone text-red mr-1 font18"></i> (02) 9683 4188</p>
                <span class=""><a href="" class="font-weight-bold text-red text-underline">View Details</a></span>
              </div>
            </div>
          </div>
          <div class="col-lg-8 col-md-6 col-sm-12 col-12">
            <div id="map" style="width:100%;height:500px;"></div>
          </div>
        </div>
      </div>
  </div>
    
</div>
@endsection
@section('script')
<script>
function getLocation() {
  if (navigator.geolocation) {
    navigator.geolocation.getCurrentPosition(showPosition);
  } else {
    alert("Geolocation is not supported by this browser.");
  }
}

function showPosition(position) {
      var geocoder = new google.maps.Geocoder();
        var latLng = new google.maps.LatLng(position.coords.latitude, position.coords.longitude);

     if (geocoder) {
        geocoder.geocode({ 'latLng': latLng}, function (results, status) {
           if (status == google.maps.GeocoderStatus.OK) {
             console.log(results[0].formatted_address); 
             $('input[name=location]').val(results[0].formatted_address);
           }
           else {
            alert('Geocoding failed: '+status);
            console.log("Geocoding failed: " + status);
           }
        });
      }  
}

    function myMap() {
    var mapProp= {
      center:new google.maps.LatLng(-33.7895937,151.0138363),
      zoom:14,
      mapTypeId: 'terrain'
    };
    var map = new google.maps.Map(document.getElementById("map"),mapProp);
    }
    </script>
    <script src="//maps.googleapis.com/maps/api/js?key=AIzaSyAFOEcUFMUq61N08oTnOwBohfhNELryvVA&callback=myMap"></script>
@endsection