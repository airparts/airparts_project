@extends('master.front')
@section('meta')
<meta name="keywords" content="{{$setting->meta_keywords}}">
<meta name="description" content="{{$setting->meta_description}}">
@endsection
@section('title')
    {{__('Contact')}}
@endsection

@section('content')
<div class="about-us-bottom-area section-top-gap-100">
  <div class="section-content-gap">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> {{__('Contact Us')}} <span class="red-circle"></span>
                        </h3>  
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
      <div class="container">
          <div class="row m-0">
            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
              <h4 class="font-weight-bold">Get In Touch</h4>
              <p>
                <ul class="list-unstyled text-sm">
                  <li><span class="text-muted">{{__('Monday-Friday')}}:</span>{{$setting->friday_start}} - {{$setting->friday_end}}</li>
                  <li><span class="text-muted">{{__('Saturday')}}:</span>{{$setting->satureday_start}} - {{$setting->satureday_end}}</li>
                </ul>
              </p>
              <p>
                <ul class="list-icon margin-bottom-1x">
                  <li><strong><i class="fa fa-map-marker text-red mr-2 font18"></i></strong>{{$setting->footer_address}}</li>
                  <li><strong><i class="fa fa-phone text-red mr-2 font18"></i></strong>{{$setting->footer_phone}}</li>
                  <li>
                    <strong><i class="fa fa-clock-o text-red mr-2 font18"></i></strong> open 24/7
                  </li>
                </ul>
              </p>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
              <form class="row mt-2" method="Post" action="{{route('front.contact.submit')}}">
                @csrf
                <div class="form-group">
                  <h4 class="font-weight-bold">Leaver a Reply</h4>
                  <p>Tell Us Your Message , We will review your request.</p>
                </div>
                <div class="form-group mb-2">
                  <textarea class="form-control" name="message" rows="4" placeholder="Your comment"></textarea>
                  @error('message')
                    <p class="text-danger">{{$message}}</p>
                    @enderror
                </div>
                <div class="form-group mb-2">
                  <input type="text" name="first_name" placeholder="First Name*" class="form-control">
                  @error('first_name')
                    <p class="text-danger">{{$message}}</p>
                    @enderror
                </div>
                <div class="form-group mb-2">
                  <input type="text" name="last_name" placeholder="Name*" class="form-control">
                  @error('last_name')
                    <p class="text-danger">{{$message}}</p>
                    @enderror
                </div>
                <div class="form-group mb-2">
                  <input type="email" name="email" placeholder="Email*" class="form-control">
                  @error('email')
                    <p class="text-danger">{{$message}}</p>
                    @enderror
                </div>
                <div class="form-group mb-2">
                  <input type="text" name="phone" placeholder="Email*" class="form-control">
                  @error('phone')
                    <p class="text-danger">{{$message}}</p>
                    @enderror
                </div>
                <div class="form-group">
                  <button type="submit" class="btn btn-danger-o">Submit Comment</button>
                </div>
              </form>
            </div>
          </div>
      </div>
  </div>
    
</div>

<div class="section-content-gap section-top-gap-100">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> About Us <span class="red-circle"></span>
                        </h3>  
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
      <div class="container">
        <div class="row m-0">
          <div class="col-12">
            {!! $about_us->details !!}
          </div>
        </div>
      </div>
  </div>

  <div class="section-content-gap section-top-gap-100">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> FAQ <span class="red-circle"></span>
                        </h3>  
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
      <div class="container">
        <div class="row m-0">
        @foreach($faqs as $key => $faq)
          <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12 mt-5">
              <div class="panel-group" id="accordion{{ $key }}" role="tablist" aria-multiselectable="true">
                  <div class="panel panel-default faq">
                      <div class="panel-heading1" role="tab" id="heading{{ $key }}">
                          <h6 class="font-weight-bold panel-title"> 
                            <a data-toggle="collapse" data-parent="#accordion{{ $key }}" href="#collapse{{ $key }}" aria-expanded="true" aria-controls="collapse{{ $key }}">{{ $faq->title }}</a>
                          </h6>
                      </div>
                      <div id="collapse{{ $key }}" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="heading{{ $key }}">
                          <div class="panel-body mt-5">
                            {!! $faq->details !!}
                          </div>
                      </div>
                  </div>
              </div>
            </div>
            @endforeach
        </div>
      </div>
  </div>

  <div class="section-content-gap section-top-gap-100">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> Invest on Us <span class="red-circle"></span>
                        </h3>  
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
      <div class="container">
        <div class="row m-0">
          <div class="col-lg-12 col-md-12 col-sm-12 col-12">
              <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-3 col-12 mb-1">
                  <img src="{{ asset('assets/img/mask-group-10@1x.png') }}" width="100%" height="auto" />
                </div>
                <div class="col-lg-9 col-md-9 col-sm-9 col-12">
                  <h6 class="font-weight-bold">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor</h6>
                  <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>
                  <button class="btn btn-danger-o">Know More</button>
                </div>
              </div>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-12 mt-3">
              <div class="banner-single zIndex1">
                <a  class="banner-img-link">
                    <img class="banner-img banner-img-big" src="{{ asset('assets/img/mask-group-11@1x.png') }}" alt="">
                </a>
                <div class="banner-content">
                    <h3 class="section-title text-white mt-5 pt-5"><span class="white-line"></span> Become a Workshop Partner <span class="white-circle"></span> </h3>
                    <div class="banner-content-wrapper mt-5">
                        <div class="container">
                          <div class="row pl-5 ml-5">
                              <div class="col-lg-10 col-md-10 col-sm-12 col-12">
                                  <p class="text-white"><strong>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua.</strong></p>
                              </div>
                              <div class="col-lg-2 col-md-2 col-sm-12 col-12">
                                  <button class="btn btn-danger">Know More</button>
                              </div>
                          </div>
                        </div>
                    </div>
                </div>
            </div>
            </div>
            <div class="col-12 mt-15 mb-10">
              <div class="row">
                <div class="col-lg-5 col-md-5 col-sm-12 col-12 mb-1">
                  <img src="{{ asset('assets/img/mask-group-12@1x.png') }}" width="100%" height="auto" />
                </div>
                <div class="col-lg-7 col-md-7 col-sm-12 col-12">
                  <h3 class="font-weight-bold">Become a Shipping Partner</h3>
                  <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>
                  <div class="form-group">
                    <h6>Enter your Email</h6>
                    <input type="email" name="" class="form-control" placeholder="Email*">
                  </div>
                  <button class="btn btn-danger-o mt-3">Get Started</button>
                </div>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-12 mb-2">
                  <h3 class="font-weight-bold">Terms & Conditions</h3>
                  <p>{{ $terms->meta_descriptions }}</p>
                  <a class="btn btn-danger-o" href="{{ url($terms->slug) }}">Read More</a>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                  <h3 class="font-weight-bold">Privacy Statement</h3>
                  <p>{{ $privacy->meta_descriptions }}</p>
                  <a class="btn btn-danger-o" href="{{ url($privacy->slug) }}">Read More</a>
            </div>
            <div class="col-lg-12 col-md-12 col-sm-12 col-12 mt-10">
              <div class="row">
                <div class="col-lg-5 col-md-5 col-sm-12 col-12 mb-1">
                  <img src="{{ asset('assets/img/mask-group-13@1x.png') }}" width="100%" height="auto" />
                </div>
                <div class="col-lg-7 col-md-7 col-sm-12 col-12">
                  <div class="form-group mb-3">
                    <h6 class="font-weight-bold mt-0">Order ID</h6>
                    <input type="text" name="" class="form-control" placeholder="Enter order id">
                  </div>
                  <div class="form-group mb-3">
                    <h6 class="font-weight-bold">Description</h6>
                    <textarea class="form-control" rows="4" placeholder="Describe the Problem in Details"></textarea>
                  </div>
                  <button class="btn btn-danger-o">Submit</button>
                </div>
              </div>
            </div>
        </div>
      </div>
  </div>
@endsection
