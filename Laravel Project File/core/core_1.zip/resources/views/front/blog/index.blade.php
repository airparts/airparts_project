@extends('master.front')

@section('title')
    {{__('Blog')}}
@endsection

@section('content')
<div class="about-us-bottom-area section-top-gap-100">
  <div class="section-content-gap">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> Blogs <span class="red-circle"></span>
                        </h3>  
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 col-12 pl-5">
                      <form action="{{route('front.blog')}}" method="get">
                      <div class="form-group d-flex float-right">
                        <div class="form-group w200x mr-3">
                          <select class="form-control" name="type">
                              <option value="">All Posts</option>
                              <option value="">Recent Posts</option>
                              <option value="">Mostly Viewed</option>
                          </select>
                        </div>
                        <div class="input-group mb-3 w200x">
                          <span class="input-group-text" style="background: none;" id="basic-addon1"><i class="fa fa-search"></i></span>
                          <input type="text" name="search" class="form-control" placeholder="Search Blog" aria-label="Search" aria-describedby="basic-addon1" style="border-left: 0;height: 42px;">
                        </div>
                      </div>
                    </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
  <div class="post_ad-wrapper content-wrapper">
      <div class="container">
          <div class="row m-0">
            @foreach ($posts as $k => $post)
            @if($k==0)
            <div class="col-lg-12 col-md-12 col-sm-12 col-12">
              @if(isset(json_decode($post->photo, true)[array_key_first(json_decode($post->photo, true))]))
                <img src="{{ asset('assets/images/' . json_decode($post->photo, true)[array_key_first(json_decode($post->photo, true))]) }}" alt="" class="blog-feed-img">
                @else
                <img src="https://via.placeholder.com/600" alt="" class="blog-feed-img">
                @endif
              <h4 class="font-weight-bold mt-3 mb-3"><a href="{{route('front.blog.details',$post->slug)}}">{{ strlen(strip_tags($post->title)) > 55 ? substr(strip_tags($post->title), 0, 55) : strip_tags($post->title) }}</a></h4>
              <p>{{ strlen(strip_tags($post->details)) > 400 ? substr(strip_tags($post->details), 0, 120) : strip_tags($post->details) }}</p>
              <span class="text-secondary"><i class="fa fa-calendar"></i> {{ date('F d, Y',strtotime($post->created_at)) }}</span>
              <a href="{{route('front.blog.details',$post->slug)}}" class="float-right btn btn-danger-o">Read More</a>
            </div>
            @else
            <div class="col-lg-12 col-md-12 col-sm-12 col-12 mt-3">
              <div class="row">
                <div class="col-lg-3 col-md-3 col-sm-3 col-12 mb-1">
                  <img src="{{ asset('assets/images/' . json_decode($post->photo, true)[array_key_first(json_decode($post->photo, true))]) }}" width="100%" height="auto" />
                </div>
                <div class="col-lg-9 col-md-9 col-sm-9 col-12">
                  <p class="text-secondary"><i class="fa fa-calendar"></i> {{ date('F d, Y',strtotime($post->created_at)) }}</p>
                  <h6 class="font-weight-bold"><a href="{{route('front.blog.details',$post->slug)}}">{{ strlen(strip_tags($post->title)) > 55 ? substr(strip_tags($post->title), 0, 55) : strip_tags($post->title) }}</a></h6>
                  <p>{{ strlen(strip_tags($post->details)) > 120 ? substr(strip_tags($post->details), 0, 120) : strip_tags($post->details) }}</p>
                  <a href="{{route('front.blog.details',$post->slug)}}" class="btn btn-danger-o">Read More</a>
                </div>
              </div>
            </div>
            @endif
            @endforeach
            {{ $posts->links('vendor.pagination.custom') }}
          </div>
      </div>
  </div>
    
</div>

@endsection
