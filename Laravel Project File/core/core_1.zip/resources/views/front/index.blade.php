@section('hometitle')
    {{ $setting->home_page_title }}
@endsection
@includeIf('front.themes.theme1')