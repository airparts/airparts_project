@extends('master.front')
@section('meta')
<meta name="keywords" content="{{$setting->meta_keywords}}">
<meta name="description" content="{{$setting->meta_description}}">
@endsection
@section('title')
    {{__('Brand')}}
@endsection

@section('content')
<div class="about-us-bottom-area section-top-gap-100">
  <div class="section-content-gap">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> {{__('Brands')}} <span class="red-circle"></span>
                        </h3>  
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
<div class="post_ad-wrapper content-wrapper">
  <div class="container pt-0 pb-5">
    <div class="row g-3">
        @foreach ($brands as $brand)
            <div class="col-lg-2 col-md-4 col-sm-4 col-6">
                            <!-- Start Product Catagory Single -->
                            <a href="{{ route('front.catalog') . '?brand=' . $brand->slug }}" class="product-catagory-single">
                                <div class="product-catagory-img">
                                    <img src="{{ asset('assets/images/' . $brand->photo) }}" alt="{{ $brand->name }}" title="{{ $brand->name }}">
                                </div>
                                <div class="product-catagory-content">
                                    <h5 class="product-catagory-title mt-4"><strong>{{ $brand->name }}</strong></h5>
                                </div>
                            </a> <!-- End Product Catagory Single -->
                        </div>
        @endforeach
    </div>
  </div>
 </div>
</div>
@endsection
