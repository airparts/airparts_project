@extends('master.front')
@section('meta')
    <meta name="keywords" content="{{ $setting->meta_keywords }}">
    <meta name="description" content="{{ $setting->meta_description }}">
@endsection

@section('content')
@php
    function renderStarRating($rating, $maxRating = 5)
    {
        $fullStar = "<i class = 'far fa-star filled'></i>";
        $halfStar = "<i class = 'far fa-star-half filled'></i>";
        $emptyStar = "<i class = 'far fa-star'></i>";
        $rating = $rating <= $maxRating ? $rating : $maxRating;

        $fullStarCount = (int) $rating;
        $halfStarCount = ceil($rating) - $fullStarCount;
        $emptyStarCount = $maxRating - $fullStarCount - $halfStarCount;

        $html = str_repeat($fullStar, $fullStarCount);
        $html .= str_repeat($halfStar, $halfStarCount);
        $html .= str_repeat($emptyStar, $emptyStarCount);
        $html = $html;
        return $html;
    }
@endphp
    <!-- ...:::: Start Hero Area Section:::... -->
        <div class="hero-area">
            <div class="hero-area-wrapper hero-slider-dots fix-slider-dots">
                <!-- Start Hero Slider Single -->
                @foreach ($sliders as $slider)
                <div class="hero-area-single">
                    <div class="hero-area-bg">
                        <img class="hero-img" src="{{ asset('assets/images/' . $slider->photo) }}" alt="">
                    </div>
                    <div class="hero-content">
                        <div class="container">
                            <div class="row">
                                <div class="col-10 col-md-8 col-xl-6">
                                    <h5>{!! $slider->title !!}</h5>
                                    <h2 class="slider_h2 mt-5">{!! $slider->details !!}</h2>
                                    <a href="{{ $slider->link }}" class="hero-button">{{ __('Explore More') }}</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div> <!-- End Hero Slider Single -->
                @endforeach
            </div>
        </div> <!-- ...:::: End Hero Area Section:::... -->

        <!-- ...:::: Start Product Catagory Section:::... -->
        <div class="product-catagory-section section-top-gap-100">
            <!-- Start Section Content -->
            <div class="section-content-gap">
                <div class="container">
                    <div class="row">
                        <div class="section-content">
                            <h3 class="section-title"><span class="red-line"></span> {{ __('Select Parts By Make') }} <span class="red-circle"></span> <a class="btn btn-default btn-sm float-right" href="{{ route('front.brand') }}">{{ __('View All') }} <i class="fa fa-arrow-right"></i></a></h3>
                        </div>
                    </div>
                </div>
            </div> <!-- End Section Content -->

            <!-- Start Catagory Wrapper -->
            <div class="product-catagory-wrapper">
                <div class="container">
                    <div class="row">
                        @foreach ($brands as $brand)
                        <div class="col-lg-2 col-md-4 col-sm-4 col-6">
                            <!-- Start Product Catagory Single -->
                            <a href="{{ route('front.catalog') . '?brand=' . $brand->slug }}" class="product-catagory-single">
                                <div class="product-catagory-img">
                                    <img src="{{ asset('assets/images/' . $brand->photo) }}" alt="{{ $brand->name }}" title="{{ $brand->name }}">
                                </div>
                                <div class="product-catagory-content">
                                    <h5 class="product-catagory-title mt-4"><strong>{{ $brand->name }}</strong></h5>
                                </div>
                            </a> <!-- End Product Catagory Single -->
                        </div>
                        @endforeach
                    </div>
                </div>
            </div> <!-- End Catagory Wrapper -->
        </div> <!-- ...:::: End Product Catagory Section:::... -->

        <!-- ...:::: Start Product Tab Section:::... -->
        <div class="product-tab-section section-top-gap-100">
            <!-- Start Section Content -->
            <div class="section-content-gap">
                <div class="container">
                    <div class="row">
                        <div class="section-content d-flex justify-content-between align-items-md-center align-items-start flex-md-row flex-column">
                            <h3 class="section-title"><span class="red-line"></span> {{ __('Recently Viewed Items') }} <span class="red-circle"></span> 
                                <a class="btn btn-default btn-sm float-right" href="{{ route('front.catalog') }}">{{ __('View All') }} <i class="fa fa-arrow-right"></i></a>
                            </h3>
                        </div>
                    </div>
                </div>
            </div> <!-- End Section Content -->

            <!-- Start Tab Wrapper -->
            <div class="product-tab-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="tab-content tab-animate-zoom">
                                <div class="tab-pane show active" id="car_and_drive">
                                    <div class="product-default-slider product-default-slider-4grids-1row">
                                    @foreach($recent_items as $item)
                                        <div class="product-default-single border-around">
                                            <div class="product-img-warp">
                                                <a href="{{route('front.product',$item->slug)}}" class="product-default-img-link">
                                                    <img src="{{asset('assets/images/'.$item->thumbnail)}}" alt="Product" class="product-default-img img-fluid">
                                                </a>
                                            </div>
                                            <div class="product-default-content">
                                                <p class="mb-1 op06"><span class="text-red"><strong>{{ __('Category') }}: </strong></span>
                                                    <a href="{{route('front.catalog').'?category='.$item->category->slug}}">
                                                        {{$item->category->name}}
                                                    </a>
                                                    </p>
                                                <h6 class="product-default-link"><a href="{{route('front.product',$item->slug)}}">{{ strlen(strip_tags($item->name)) > 35 ? substr(strip_tags($item->name), 0, 35) : strip_tags($item->name) }}</a></h6>
                                                <div class="product_stars rating-stars">
                                                    {!! renderStarRating($item->reviews->avg('rating')) !!}
                                                  </div>
                                                  <div class="row mt-1">
                                                      <div class="col-xl-6 col-lg-12 col-md-6 col-6">
                                                        @if((!$item->is_stock()))
                                                        <h6 class="text-red">{{__('out of stock')}}</h6>
                                                        @else
                                                        <h4 class="text-red"><strong>
                                                            {{PriceHelper::grandCurrencyPrice($item)}}
                                                        </strong></h4>
                                                        @endif
                                                      </div>
                                                      <div class="col-xl-6 col-lg-12 col-md-6 col-6 d-flex pt-1 justify-content-end">
                                                        <img class="icon-material-location-on" width="15" height="18" src="{{ asset('assets/assets/images/icon/icon-material-location-on-10@1x.png') }}">
                                                        <div class="place barlow-medium-black-15px-2">{{ __($item->country) }}</div>
                                                        <img class="group-390" width="20" height="20" src="{{ asset('assets/assets/images/icon/group-390-11@1x.png') }}">
                                                      </div>
                                                      <div class="col-12 mt-1">
                                                          <a data-target="{{ $item->id }}" href="javascript:;" class="btn btn-red btn-block add_to_single_cart">Add to Cart</a>
                                                      </div>
                                                  </div>
                                            </div>
                                            <a class="product_wish_icon wishlist_store" href="javascript:void(0);" data-href="{{route('user.wishlist.store',$item->id)}}"><i class="icon-heart"></i></a>
                                        </div>
                                    @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- End Catagory Wrapper -->

        </div> <!-- ...:::: Start Product Tab Section:::... -->
        <!-- ...:::: Start Product Catagory Section:::... -->
        <div class="product-catagory-section section-top-gap-100">
            <!-- Start Section Content -->
            <div class="section-content-gap">
                <div class="container">
                    <div class="row">
                        <div class="section-content">
                            <h3 class="section-title"><span class="red-line"></span> {{ __('Categories') }} <span class="red-circle"></span> <a class="btn btn-default btn-sm float-right" href="{{ route('front.category') }}">{{ __('View All') }} <i class="fa fa-arrow-right"></i></a></h3>
                        </div>
                    </div>
                </div>
            </div> <!-- End Section Content -->

            <!-- Start Catagory Wrapper -->
            <div class="product-catagory-wrapper">
                <div class="container">
                    <div class="row">
                        @foreach($categories as $category)
                        <div class="col-lg-2 col-md-3 col-sm-6 col-6 mb-1">
                            <!-- Start Product Catagory Single -->
                            <a href="{{route('front.catalog').'?category='.$category->slug}}" class="product-catagory-single only-category">
                                <div class="product-catagory-img">
                                    <img src="{{ $category->photo ? asset('assets/images/'.$category->photo) : asset('assets/images/placeholder.png') }}"
                                                alt="No Image Found">
                                </div>
                                <div class="product-catagory-content">
                                    <h5 class="product-catagory-title mt-4"><strong>{{ $category->name }}</strong></h5>
                                </div>
                            </a> <!-- End Product Catagory Single -->
                        </div>
                        @endforeach
                    </div>
                </div>
            </div> <!-- End Catagory Wrapper -->
        </div> <!-- ...:::: End Product Catagory Section:::... -->

        <!-- ...:::: Start Product Catagory Section:::... -->
        <div class="banner-section section-top-gap-100">
            <!-- Start Banner Wrapper -->
            <div class="banner-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <!-- Start Banner Single -->
                            <div class="banner-single zIndex1">
                                <a  class="banner-img-link">
                                    <img class="banner-img banner-img-big" src="{{ asset('assets/assets/images/banner_images/mask-group-2@1x.png') }}" alt="">
                                </a>
                                <div class="banner-content">
                                    <h3 class="section-title text-white mt-5 pt-5"><span class="white-line"></span> Search By Car <span class="white-circle"></span> </h3>
                                    <div class="banner-content-wrapper mt-5">
                                        <div class="container">
                                            <form role="form" method="get" action="{{ route('front.catalog') }}">
                                                <div class="row pl-5 ml-5">
                                                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                                                        <div class="form-group">
                                                            <select class="form-control" name="year">
                                                                <option value="">Select the Year</option>
                                                                @for($i=2000; $i<=date('Y'); $i++)
                                                                <option value="{{ $i }}">{{ $i }}</option>
                                                                @endfor
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                                                        <div class="form-group">
                                                            <select class="form-control" name="brand">
                                                                <option value="">Select the Brand</option>
                                                                @foreach(\App\Models\Brand::whereStatus(1)->orderBy('position','asc')->get() as $brand)
                                                                <option value="{{ $brand->slug }}">{{ $brand->name }}</option>
                                                                @endforeach
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                                                        <div class="form-group">
                                                            <select class="form-control" name="model">
                                                                <option value="">Select the Model</option>
                                                                @for($i=2000; $i<=date('Y'); $i++)
                                                                <option value="{{ $i }}">{{ $i }}</option>
                                                                @endfor
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                                                        <div class="form-group">
                                                            <button type="submit" class="btn btn-red">Search the Car</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div> <!-- End Banner Single -->
                        </div>
                    </div>
                </div>
            </div> <!-- End Banner Wrapper -->
        </div> <!-- ...:::: End Product Catagory Section:::... -->

        <!-- ...:::: Start Product Tab Section:::... -->
        <div class="product-tab-section section-top-gap-100">
            <!-- Start Section Content -->
            <div class="section-content-gap">
                <div class="container">
                    <div class="row">
                        <div class="section-content d-flex justify-content-between align-items-md-center align-items-start flex-md-row flex-column">
                            <h3 class="section-title zi--1 w-80"><span class="red-line"></span> Top Deals <span class="red-circle"></span></h3>
                            <a class="btn btn-default btn-sm float-right" href="{{ route('front.catalog') }}">{{ __('View All') }} <i class="fa fa-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
            </div> <!-- End Section Content -->

            <!-- Start Tab Wrapper -->
            <div class="product-tab-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <div class="tab-content tab-animate-zoom">
                                <div class="tab-pane active show" id="drive_and_car">
                                    <div class="product-default-slider product-default-slider-4grids-1row">
                                    @foreach ($products->where('is_type','top')->orderBy('id','DESC')->get()  as $item)
                                    <div class="product-default-single">
                                        <div class="product-wrap border-around">
                                            <div class="product-img-warp">
                                                <a href="{{route('front.product',$item->slug)}}" class="product-default-img-link">
                                                    <img src="{{asset('assets/images/'.$item->thumbnail)}}" alt="" class="product-default-img img-fluid">
                                                </a>
                                            </div>
                                            <div class="product-default-content">
                                                <p class="mb-1 op06"><span class="text-red"><strong>{{ __('Category') }}: </strong></span><a href="{{route('front.catalog').'?category='.$item->category->slug}}">
                                                        {{$item->category->name}}
                                                    </a></p>
                                                <h6 class="product-default-link"><a href="{{route('front.product',$item->slug)}}">{{ strlen(strip_tags($item->name)) > 35 ? substr(strip_tags($item->name), 0, 35) : strip_tags($item->name) }}</a></h6>
                                                <div class="product_stars rating-stars">
                                                    {!! renderStarRating($item->reviews->avg('rating')) !!}
                                                </div>
                                                <div class="row mt-1">
                                                      <div class="col-xl-6 col-lg-12 col-md-6 col-6">
                                                        @if((!$item->is_stock()))
                                                        <h6 class="text-red">{{__('out of stock')}}</h6>
                                                        @else
                                                        <h4 class="text-red"><strong>
                                                            {{PriceHelper::grandCurrencyPrice($item)}}
                                                        </strong></h4>
                                                        @endif
                                                      </div>
                                                      <div class="col-xl-6 col-lg-12 col-md-6 col-6 d-flex pt-1 justify-content-end">
                                                        <img class="icon-material-location-on" width="15" height="18" src="{{ asset('assets/assets/images/icon/icon-material-location-on-10@1x.png') }}">
                                                        <div class="place barlow-medium-black-15px-2">{{ __($item->country) }}</div>
                                                        <img class="group-390" width="20" height="20" src="{{ asset('assets/assets/images/icon/group-390-11@1x.png') }}">
                                                      </div>
                                                      <div class="col-12 mt-1">
                                                          <a data-target="{{ $item->id }}" href="javascript:;" class="btn btn-red btn-block add_to_single_cart">Add to Cart</a>
                                                      </div>
                                                  </div>
                                              </div>
                                        </div>
                                        <a class="product_wish_icon wishlist_store" href="javascript:void(0);" data-href="{{route('user.wishlist.store',$item->id)}}"><i class="icon-heart"></i></a>
                                    </div>
                                    @endforeach
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div> <!-- End Catagory Wrapper -->
        </div> <!-- ...:::: End Product Tab Section:::... -->

        <!-- ...:::: Start Product Catagory Section:::... -->
        <div class="banner-section section-top-gap-100">
            <!-- Start Banner Wrapper -->
            <div class="banner-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-12">
                            <!-- Start Banner Single -->
                            <div class="banner-single">
                                <a  class="banner-img-link">
                                    <img class="banner-img banner-img-big" src="{{ asset('assets/assets/images/banner_images/mask-group-3@1x.png') }}" alt="">
                                </a>
                                <div class="banner-content">
                                    <h3 class="section-title text-white mt-5 pt-5"><span class="white-line"></span> {{ __('Subscribe to our Newsletter') }} <span class="white-circle"></span> </h3>
                                    <div class="banner-content-wrapper mt-5">
                                        <div class="container">
                                            <form  class="subscriber-form" role="form" action="{{route('front.subscriber.submit')}}" method="post">
                                                @csrf
                                                <div class="row pl-5 ml-5">
                                                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                                        <div class="form-group">
                                                            <p class="text-white"><strong>{!! __('Get updates and score the best deals for your pride and joy in the air!') !!}</strong></p>
                                                        </div>
                                                    </div>
                                                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                                        <div class="form-group">
                                                            <input type="email" name="email" value="" placeholder="{{ __('Enter your Email') }}..." class="form-control" />
                                                        </div>
                                                    </div>
                                                     <input type="hidden" name="b_c7103e2c981361a6639545bd5_1194bb7544" tabindex="-1">
                                                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                                                        <div class="form-group">
                                                            <button type="submit" class="btn btn-red">{{ __('Subscribe') }}</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div> <!-- End Banner Single -->
                        </div>
                    </div>
                </div>
            </div> <!-- End Banner Wrapper -->
        </div> <!-- ...:::: End Product Catagory Section:::... -->

        <!-- ...:::: Start Blog Feed Section:::... -->
        <div class="blog-feed-section section-top-gap-100">
            <!-- Start Section Content -->
            <div class="section-content-gap">
                <div class="container">
                    <div class="row">
                        <div class="section-content">
                            <h3 class="section-title"><span class="red-line"></span> {{ __('From the Blog') }} <span class="red-circle"></span></h3>
                        </div>
                    </div>
                </div>
            </div> <!-- End Section Content -->

            <!-- Start Blog Feed Wrapper -->
            <div class="blog-feed-wrapper">
                <div class="container">
                    <div class="row">
                        @foreach ($posts as $k => $post)
                        @if($k==0)
                        <div class="col-lg-6 col-md-6 col-12">
                            <!-- Start Blog Feed Single -->
                            <div class="blog-feed-single">
                                <a href="{{route('front.blog.details',$post->slug)}}" class="blog-feed-img-link">
                                    @if(isset(json_decode($post->photo, true)[array_key_first(json_decode($post->photo, true))]))
                                    <img src="{{ asset('assets/images/' . json_decode($post->photo, true)[array_key_first(json_decode($post->photo, true))]) }}" alt="" class="blog-feed-img">
                                    @else
                                    <img src="https://via.placeholder.com/600" alt="" class="blog-feed-img">
                                    @endif
                                </a>
                                <div class="blog-feed-content">
                                    <div class="blog-feed-post-meta">
                                        <div class="group-433 op06">
                                            <img class="path-157 mb-1" width="17px" src="{{ asset('assets/assets/images/icon/path-157-1@1x.png') }}">
                                            <span class="date-1 barlow-medium-black-14px">{{ date('jS F, Y', strtotime($post->created_at)) }}</span>
                                          </div>
                                    </div>
                                    <h5 class="blog-feed-link"><a href="{{route('front.blog.details',$post->slug)}}">{{ strlen(strip_tags($post->title)) > 55 ? substr(strip_tags($post->title), 0, 55) : strip_tags($post->title) }}</a></h5>
                                    <div class="desc">
                                        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren,</p>
                                    </div>
                                    <a href="{{route('front.blog.details',$post->slug)}}" class="btn btn-red">{{ __('Read More') }}</a>
                                </div>
                            </div><!-- End Blog Feed Single -->
                        </div>
                        @else
                        @if($k==1)
                        <div class="col-lg-6 col-md-6 col-12">
                            <div class="row">
                        @endif
                                <div class="col-12">
                                    <div class="row mb-2">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="blog-image-wrapper">
                                                <a href="{{route('front.blog.details',$post->slug)}}"  class="blog-img-link">
                                                    <img src="{{ asset('assets/images/' . json_decode($post->photo, true)[array_key_first(json_decode($post->photo, true))]) }}" alt="" class="blog-realted-img">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class="content-blog">
                                                  <div class="group-433 op06">
                                                     <img class="path-157 mb-1" width="17px" src="{{ asset('assets/assets/images/icon/path-157-1@1x.png') }}">
                                                    <span class="date-1 barlow-medium-black-14px">{{ date('jS F, Y', strtotime($post->created_at)) }}</span>
                                                  </div>
                                                  <div class="lorem-ipsum-dolor-si barlow-semi-bold-black-20px">
                                                    <h6>{{ strlen(strip_tags($post->title)) > 55 ? substr(strip_tags($post->title), 0, 55) : strip_tags($post->title) }}</h6>
                                                  </div>
                                                  <div class="group-434 border-1px-alizarin-crimson">
                                                    <a href="{{route('front.blog.details',$post->slug)}}" class="btn btn-red">{{ __('Read More') }}</a>
                                                  </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                        @if(count($posts)-1==$k)        
                            </div>
                        </div>
                        @endif
                        @endif
                        @endforeach
                    </div>
                </div>
            </div> <!-- End Blog Feed Wrapper -->


        </div> <!-- ...:::: End Blog Feed Section:::... -->

        <!-- ...:::: Start Testimonial Feed Section:::... -->
        <div class="blog-feed-section section-top-gap-100">
            <!-- Start Section Content -->
            <div class="section-content-gap">
                <div class="container">
                    <div class="row">
                        <div class="section-content">
                            <h3 class="section-title"><span class="red-line"></span> {{ __('Testimonials') }} <span class="red-circle"></span></h3>
                        </div>
                    </div>
                </div>
            </div> <!-- End Section Content -->

            <!-- Start Testimonial Feed Wrapper -->
            <div class="blog-feed-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6 col-md-6 col-12">
                            <!-- Start Testimonial Feed Single -->
                            <div class="testimonial-wrapper d-block">
                                <img src="{{ asset('assets/assets/images/blog_images/path-158@1x.png') }}" />
                                <p class="op06">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>
                                <div class="product_stars d-flex">
                                    <img class="icon-awesome-star-1 mr-1" src="{{ asset('assets/assets/images/icon/icon-awesome-star-100@1x.png') }}">
                                    <img class="icon-awesome-star-2 mr-1" src="{{ asset('assets/assets/images/icon/icon-awesome-star-100@1x.png') }}">
                                    <img class="icon-awesome-star-2 mr-1" src="{{ asset('assets/assets/images/icon/icon-awesome-star-100@1x.png') }}">
                                    <img class="icon-awesome-star-2 mr-1" src="{{ asset('assets/assets/images/icon/icon-awesome-star-100@1x.png') }}">
                                    <img class="icon-awesome-star-2" src="{{ asset('assets/assets/images/icon/icon-awesome-star-100@1x.png') }}">
                                </div>
                                <div class="testimonial-footer d-flex mt-3">
                                    <div class="user_image">
                                        <img  width="50px" class="mr-4" src="{{ asset('assets/assets/images/blog_images/ellipse-2@1x.png') }}" />
                                    </div>
                                    <div class="user_info d-block">
                                        <h6><strong>Emilia Clark</strong></h6>
                                        <span class="op06">Jan 20, 2021</span>
                                    </div>
                                </div>
                            </div>
                            <!-- End Testimonial Feed Single -->
                        </div>
                        <div class="col-lg-6 col-md-6 col-12">
                            <!-- Start Testimonial Feed Single -->
                            <div class="testimonial-wrapper d-block">
                                <img src="{{ asset('assets/assets/images/blog_images/path-158@1x.png') }}" />
                                <p class="op06">Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.</p>
                                <div class="product_stars d-flex">
                                    <img class="icon-awesome-star-1 mr-1" src="{{ asset('assets/assets/images/icon/icon-awesome-star-100@1x.png') }}">
                                    <img class="icon-awesome-star-2 mr-1" src="{{ asset('assets/assets/images/icon/icon-awesome-star-100@1x.png') }}">
                                    <img class="icon-awesome-star-2 mr-1" src="{{ asset('assets/assets/images/icon/icon-awesome-star-100@1x.png') }}">
                                    <img class="icon-awesome-star-2 mr-1" src="{{ asset('assets/assets/images/icon/icon-awesome-star-100@1x.png') }}">
                                    <img class="icon-awesome-star-2" src="{{ asset('assets/assets/images/icon/icon-awesome-star-100@1x.png') }}">
                                </div>
                                <div class="testimonial-footer d-flex mt-3">
                                    <div class="user_image">
                                        <img width="50px" class="mr-4" src="{{ asset('assets/assets/images/blog_images/ellipse-27@1x.png') }}" />
                                    </div>
                                    <div class="user_info d-block">
                                        <h6><strong>Trinity Reeves</strong></h6>
                                        <span class="op06">Jan 20, 2021</span>
                                    </div>
                                </div>
                            </div>
                            <!-- End Testimonial Feed Single -->
                        </div>
                    </div>
                </div>
            </div> <!-- End Testimonial Feed Wrapper -->

        </div> <!-- ...:::: End Testimonial Feed Section:::... -->

@endsection

