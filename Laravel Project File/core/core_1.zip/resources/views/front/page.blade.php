@extends('master.front')
@section('meta')
<meta name="keywords" content="{{$page->meta_keywords}}">
<meta name="description" content="{{$page->meta_descriptions}}">
@endsection
@section('title')
    {{__('Page')}}
@endsection

@section('content')
<div class="about-us-bottom-area section-top-gap-100">
  <div class="section-content-gap">
    <div class="container-fluid">
        <div class="row mr-0">
            <div class="section-content">
                <div class="row">
                    <div class="col-12">
                        <h3 class="section-title">
                            <span class="red-line"></span> {{$page->title}} <span class="red-circle"></span>
                        </h3>  
                    </div>
                </div>
            </div>
        </div>
    </div>
  </div>
<div class="post_ad-wrapper content-wrapper">
    <div class="container ">
        <!-- Categories-->
        <div class="row">
            <div class="col-lg-12 mb-4 mt-4">
                <div class="card">
                    <div class="card-body px-4 py-5">
                        <div class="d-page-content">
                            <h4 class="d-block text-center"><b>{{$page->title}}</b></h4>
                            {!! $page->details !!}
                        </div>
                    </div>
                </div>
            </div>
        </div>
      </div>
</div>

@endsection
