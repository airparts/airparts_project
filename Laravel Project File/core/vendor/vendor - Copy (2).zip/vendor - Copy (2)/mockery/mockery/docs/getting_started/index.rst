Getting Started
===============

.. toctree::
    :hidden:

    installation
    upgrading
    simple_example
    quick_reference

.. include:: map.rst.inc
