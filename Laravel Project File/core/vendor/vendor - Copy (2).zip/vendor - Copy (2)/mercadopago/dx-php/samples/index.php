<?php

  require_once 'vendor/autoload.php';
   
  
  MercadoPago\MercadoPagoSdk::initialize(); 
  $config = MercadoPago\MercadoPagoSdk::config(); 
   
  
?>