<?php
 
namespace MercadoPago;

class ErrorCause {

    public $code = ""; 
    public $description = "";

}

?>